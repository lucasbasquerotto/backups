-- MariaDB dump 10.17  Distrib 10.5.3-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: ghost_db
-- ------------------------------------------------------
-- Server version	10.5.3-MariaDB-1:10.5.3+maria~bionic-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `actions`
--

DROP TABLE IF EXISTS `actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `actions` (
  `id` varchar(24) NOT NULL,
  `resource_id` varchar(24) DEFAULT NULL,
  `resource_type` varchar(50) NOT NULL,
  `actor_id` varchar(24) NOT NULL,
  `actor_type` varchar(50) NOT NULL,
  `event` varchar(50) NOT NULL,
  `context` text DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `actions`
--

LOCK TABLES `actions` WRITE;
/*!40000 ALTER TABLE `actions` DISABLE KEYS */;
INSERT INTO `actions` VALUES ('6091ef3c517db00001e53839','1','user','1','user','edited',NULL,'2021-05-05 01:05:00'),('6091ef6d517db00001e5383c','6091ec1c517db00001e536ed','post','1','user','edited',NULL,'2021-05-05 01:05:49'),('6091ef87517db00001e5383d','6091ec1c517db00001e536ed','post','1','user','edited',NULL,'2021-05-05 01:06:15'),('6091ef8c517db00001e5383e','6091ec1c517db00001e536ed','post','1','user','edited',NULL,'2021-05-05 01:06:20'),('6091ef99517db00001e5383f','6091ec1c517db00001e536ed','post','1','user','edited',NULL,'2021-05-05 01:06:33'),('6091ef9c517db00001e53840','6091ec1c517db00001e536ed','post','1','user','edited',NULL,'2021-05-05 01:06:36'),('6091efac517db00001e53841','6091ec1c517db00001e536ed','post','1','user','edited',NULL,'2021-05-05 01:06:52'),('6091efb0517db00001e53842','6091ec1c517db00001e536ed','post','1','user','edited',NULL,'2021-05-05 01:06:56'),('6091efb9517db00001e53843','6091ec1c517db00001e536ed','post','1','user','edited',NULL,'2021-05-05 01:07:05'),('6091efe7517db00001e53844','1','user','1','user','edited',NULL,'2021-05-05 01:07:51');
/*!40000 ALTER TABLE `actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `api_keys`
--

DROP TABLE IF EXISTS `api_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `api_keys` (
  `id` varchar(24) NOT NULL,
  `type` varchar(50) NOT NULL,
  `secret` varchar(191) NOT NULL,
  `role_id` varchar(24) DEFAULT NULL,
  `integration_id` varchar(24) DEFAULT NULL,
  `user_id` varchar(24) DEFAULT NULL,
  `last_seen_at` datetime DEFAULT NULL,
  `last_seen_version` varchar(50) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `created_by` varchar(24) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` varchar(24) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `api_keys_secret_unique` (`secret`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_keys`
--

LOCK TABLES `api_keys` WRITE;
/*!40000 ALTER TABLE `api_keys` DISABLE KEYS */;
INSERT INTO `api_keys` VALUES ('6091ec1d517db00001e536f8','admin','bf743141783c604e755940af712a53bd1260adf813ffa1faf65ebff4d9e7ad5d','6091ec1b517db00001e53688','6091ec1d517db00001e536f7',NULL,NULL,NULL,'2021-05-05 00:51:41','1','2021-05-05 00:51:41','1'),('6091ec1d517db00001e536fa','admin','b2b08e85c8ef30758b18b18f0edbf88346606628b571b20e6f215df0d3644e32','6091ec1b517db00001e53689','6091ec1d517db00001e536f9',NULL,NULL,NULL,'2021-05-05 00:51:41','1','2021-05-05 00:51:41','1'),('6091ec1d517db00001e536fc','admin','7af0b5bb345f5c172edf179397bd7515b51b214f5f1c5757747689f1556e58f9','6091ec1c517db00001e5368a','6091ec1d517db00001e536fb',NULL,NULL,NULL,'2021-05-05 00:51:41','1','2021-05-05 00:51:41','1');
/*!40000 ALTER TABLE `api_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `brute`
--

DROP TABLE IF EXISTS `brute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `brute` (
  `key` varchar(191) NOT NULL,
  `firstRequest` bigint(20) NOT NULL,
  `lastRequest` bigint(20) NOT NULL,
  `lifetime` bigint(20) NOT NULL,
  `count` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brute`
--

LOCK TABLES `brute` WRITE;
/*!40000 ALTER TABLE `brute` DISABLE KEYS */;
INSERT INTO `brute` VALUES ('yEusp1INjto4PFGkXiaodvnki7um1x9UTWjRGMbyrOk=',1620176632932,1620176632932,1620180232935,1);
/*!40000 ALTER TABLE `brute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_batches`
--

DROP TABLE IF EXISTS `email_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `email_batches` (
  `id` varchar(24) NOT NULL,
  `email_id` varchar(24) NOT NULL,
  `provider_id` varchar(255) DEFAULT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'pending',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `email_batches_email_id_foreign` (`email_id`),
  CONSTRAINT `email_batches_email_id_foreign` FOREIGN KEY (`email_id`) REFERENCES `emails` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_batches`
--

LOCK TABLES `email_batches` WRITE;
/*!40000 ALTER TABLE `email_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_recipients`
--

DROP TABLE IF EXISTS `email_recipients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `email_recipients` (
  `id` varchar(24) NOT NULL,
  `email_id` varchar(24) NOT NULL,
  `member_id` varchar(24) NOT NULL,
  `batch_id` varchar(24) NOT NULL,
  `processed_at` datetime DEFAULT NULL,
  `delivered_at` datetime DEFAULT NULL,
  `opened_at` datetime DEFAULT NULL,
  `failed_at` datetime DEFAULT NULL,
  `member_uuid` varchar(36) NOT NULL,
  `member_email` varchar(191) NOT NULL,
  `member_name` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `email_recipients_member_id_index` (`member_id`),
  KEY `email_recipients_batch_id_foreign` (`batch_id`),
  KEY `email_recipients_delivered_at_index` (`delivered_at`),
  KEY `email_recipients_opened_at_index` (`opened_at`),
  KEY `email_recipients_failed_at_index` (`failed_at`),
  KEY `email_recipients_email_id_member_email_index` (`email_id`,`member_email`),
  CONSTRAINT `email_recipients_batch_id_foreign` FOREIGN KEY (`batch_id`) REFERENCES `email_batches` (`id`),
  CONSTRAINT `email_recipients_email_id_foreign` FOREIGN KEY (`email_id`) REFERENCES `emails` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_recipients`
--

LOCK TABLES `email_recipients` WRITE;
/*!40000 ALTER TABLE `email_recipients` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_recipients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `emails`
--

DROP TABLE IF EXISTS `emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `emails` (
  `id` varchar(24) NOT NULL,
  `post_id` varchar(24) NOT NULL,
  `uuid` varchar(36) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'pending',
  `recipient_filter` varchar(50) NOT NULL DEFAULT 'paid',
  `error` varchar(2000) DEFAULT NULL,
  `error_data` longtext DEFAULT NULL,
  `email_count` int(10) unsigned NOT NULL DEFAULT 0,
  `delivered_count` int(10) unsigned NOT NULL DEFAULT 0,
  `opened_count` int(10) unsigned NOT NULL DEFAULT 0,
  `failed_count` int(10) unsigned NOT NULL DEFAULT 0,
  `subject` varchar(300) DEFAULT NULL,
  `from` varchar(2000) DEFAULT NULL,
  `reply_to` varchar(2000) DEFAULT NULL,
  `html` longtext DEFAULT NULL,
  `plaintext` longtext DEFAULT NULL,
  `track_opens` tinyint(1) NOT NULL DEFAULT 0,
  `submitted_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  `created_by` varchar(24) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` varchar(24) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `emails_post_id_unique` (`post_id`),
  KEY `emails_post_id_index` (`post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `emails`
--

LOCK TABLES `emails` WRITE;
/*!40000 ALTER TABLE `emails` DISABLE KEYS */;
/*!40000 ALTER TABLE `emails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `integrations`
--

DROP TABLE IF EXISTS `integrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `integrations` (
  `id` varchar(24) NOT NULL,
  `type` varchar(50) NOT NULL DEFAULT 'custom',
  `name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `icon_image` varchar(2000) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `created_by` varchar(24) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` varchar(24) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `integrations_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `integrations`
--

LOCK TABLES `integrations` WRITE;
/*!40000 ALTER TABLE `integrations` DISABLE KEYS */;
INSERT INTO `integrations` VALUES ('6091ec1d517db00001e536f7','builtin','Zapier','zapier',NULL,'Built-in Zapier integration','2021-05-05 00:51:41','1','2021-05-05 00:51:41','1'),('6091ec1d517db00001e536f9','internal','Ghost Backup','ghost-backup',NULL,'Internal DB Backup integration','2021-05-05 00:51:41','1','2021-05-05 00:51:41','1'),('6091ec1d517db00001e536fb','internal','Ghost Scheduler','ghost-scheduler',NULL,'Internal Scheduler integration','2021-05-05 00:51:41','1','2021-05-05 00:51:41','1');
/*!40000 ALTER TABLE `integrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invites`
--

DROP TABLE IF EXISTS `invites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invites` (
  `id` varchar(24) NOT NULL,
  `role_id` varchar(24) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'pending',
  `token` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `expires` bigint(20) NOT NULL,
  `created_at` datetime NOT NULL,
  `created_by` varchar(24) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` varchar(24) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invites_token_unique` (`token`),
  UNIQUE KEY `invites_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invites`
--

LOCK TABLES `invites` WRITE;
/*!40000 ALTER TABLE `invites` DISABLE KEYS */;
/*!40000 ALTER TABLE `invites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `labels`
--

DROP TABLE IF EXISTS `labels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `labels` (
  `id` varchar(24) NOT NULL,
  `name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `created_at` datetime NOT NULL,
  `created_by` varchar(24) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` varchar(24) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `labels_name_unique` (`name`),
  UNIQUE KEY `labels_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `labels`
--

LOCK TABLES `labels` WRITE;
/*!40000 ALTER TABLE `labels` DISABLE KEYS */;
/*!40000 ALTER TABLE `labels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members`
--

DROP TABLE IF EXISTS `members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `members` (
  `id` varchar(24) NOT NULL,
  `uuid` varchar(36) DEFAULT NULL,
  `email` varchar(191) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'free',
  `name` varchar(191) DEFAULT NULL,
  `note` varchar(2000) DEFAULT NULL,
  `geolocation` varchar(2000) DEFAULT NULL,
  `subscribed` tinyint(1) DEFAULT 1,
  `email_count` int(10) unsigned NOT NULL DEFAULT 0,
  `email_opened_count` int(10) unsigned NOT NULL DEFAULT 0,
  `email_open_rate` int(10) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `created_by` varchar(24) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` varchar(24) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `members_email_unique` (`email`),
  UNIQUE KEY `members_uuid_unique` (`uuid`),
  KEY `members_email_open_rate_index` (`email_open_rate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members`
--

LOCK TABLES `members` WRITE;
/*!40000 ALTER TABLE `members` DISABLE KEYS */;
/*!40000 ALTER TABLE `members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members_email_change_events`
--

DROP TABLE IF EXISTS `members_email_change_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `members_email_change_events` (
  `id` varchar(24) NOT NULL,
  `member_id` varchar(24) NOT NULL,
  `to_email` varchar(191) NOT NULL,
  `from_email` varchar(191) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `members_email_change_events_member_id_foreign` (`member_id`),
  CONSTRAINT `members_email_change_events_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members_email_change_events`
--

LOCK TABLES `members_email_change_events` WRITE;
/*!40000 ALTER TABLE `members_email_change_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `members_email_change_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members_labels`
--

DROP TABLE IF EXISTS `members_labels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `members_labels` (
  `id` varchar(24) NOT NULL,
  `member_id` varchar(24) NOT NULL,
  `label_id` varchar(24) NOT NULL,
  `sort_order` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `members_labels_member_id_foreign` (`member_id`),
  KEY `members_labels_label_id_foreign` (`label_id`),
  CONSTRAINT `members_labels_label_id_foreign` FOREIGN KEY (`label_id`) REFERENCES `labels` (`id`) ON DELETE CASCADE,
  CONSTRAINT `members_labels_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members_labels`
--

LOCK TABLES `members_labels` WRITE;
/*!40000 ALTER TABLE `members_labels` DISABLE KEYS */;
/*!40000 ALTER TABLE `members_labels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members_login_events`
--

DROP TABLE IF EXISTS `members_login_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `members_login_events` (
  `id` varchar(24) NOT NULL,
  `member_id` varchar(24) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `members_login_events_member_id_foreign` (`member_id`),
  CONSTRAINT `members_login_events_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members_login_events`
--

LOCK TABLES `members_login_events` WRITE;
/*!40000 ALTER TABLE `members_login_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `members_login_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members_paid_subscription_events`
--

DROP TABLE IF EXISTS `members_paid_subscription_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `members_paid_subscription_events` (
  `id` varchar(24) NOT NULL,
  `member_id` varchar(24) NOT NULL,
  `from_plan` varchar(255) DEFAULT NULL,
  `to_plan` varchar(255) DEFAULT NULL,
  `currency` varchar(191) NOT NULL,
  `source` varchar(50) NOT NULL,
  `mrr_delta` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `members_paid_subscription_events_member_id_foreign` (`member_id`),
  CONSTRAINT `members_paid_subscription_events_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members_paid_subscription_events`
--

LOCK TABLES `members_paid_subscription_events` WRITE;
/*!40000 ALTER TABLE `members_paid_subscription_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `members_paid_subscription_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members_payment_events`
--

DROP TABLE IF EXISTS `members_payment_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `members_payment_events` (
  `id` varchar(24) NOT NULL,
  `member_id` varchar(24) NOT NULL,
  `amount` int(11) NOT NULL,
  `currency` varchar(191) NOT NULL,
  `source` varchar(50) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `members_payment_events_member_id_foreign` (`member_id`),
  CONSTRAINT `members_payment_events_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members_payment_events`
--

LOCK TABLES `members_payment_events` WRITE;
/*!40000 ALTER TABLE `members_payment_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `members_payment_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members_products`
--

DROP TABLE IF EXISTS `members_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `members_products` (
  `id` varchar(24) NOT NULL,
  `member_id` varchar(24) NOT NULL,
  `product_id` varchar(24) NOT NULL,
  `sort_order` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `members_products_member_id_foreign` (`member_id`),
  KEY `members_products_product_id_foreign` (`product_id`),
  CONSTRAINT `members_products_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE,
  CONSTRAINT `members_products_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members_products`
--

LOCK TABLES `members_products` WRITE;
/*!40000 ALTER TABLE `members_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `members_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members_status_events`
--

DROP TABLE IF EXISTS `members_status_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `members_status_events` (
  `id` varchar(24) NOT NULL,
  `member_id` varchar(24) NOT NULL,
  `from_status` varchar(50) DEFAULT NULL,
  `to_status` varchar(50) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `members_status_events_member_id_foreign` (`member_id`),
  CONSTRAINT `members_status_events_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members_status_events`
--

LOCK TABLES `members_status_events` WRITE;
/*!40000 ALTER TABLE `members_status_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `members_status_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members_stripe_customers`
--

DROP TABLE IF EXISTS `members_stripe_customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `members_stripe_customers` (
  `id` varchar(24) NOT NULL,
  `member_id` varchar(24) NOT NULL,
  `customer_id` varchar(255) NOT NULL,
  `name` varchar(191) DEFAULT NULL,
  `email` varchar(191) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `created_by` varchar(24) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` varchar(24) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `members_stripe_customers_customer_id_unique` (`customer_id`),
  KEY `members_stripe_customers_member_id_foreign` (`member_id`),
  CONSTRAINT `members_stripe_customers_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members_stripe_customers`
--

LOCK TABLES `members_stripe_customers` WRITE;
/*!40000 ALTER TABLE `members_stripe_customers` DISABLE KEYS */;
/*!40000 ALTER TABLE `members_stripe_customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members_stripe_customers_subscriptions`
--

DROP TABLE IF EXISTS `members_stripe_customers_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `members_stripe_customers_subscriptions` (
  `id` varchar(24) NOT NULL,
  `customer_id` varchar(255) NOT NULL,
  `subscription_id` varchar(255) NOT NULL,
  `stripe_price_id` varchar(255) NOT NULL DEFAULT '',
  `status` varchar(50) NOT NULL,
  `cancel_at_period_end` tinyint(1) NOT NULL DEFAULT 0,
  `cancellation_reason` varchar(500) DEFAULT NULL,
  `current_period_end` datetime NOT NULL,
  `start_date` datetime NOT NULL,
  `default_payment_card_last4` varchar(4) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `created_by` varchar(24) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` varchar(24) DEFAULT NULL,
  `plan_id` varchar(255) NOT NULL,
  `plan_nickname` varchar(50) NOT NULL,
  `plan_interval` varchar(50) NOT NULL,
  `plan_amount` int(11) NOT NULL,
  `plan_currency` varchar(191) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `members_stripe_customers_subscriptions_subscription_id_unique` (`subscription_id`),
  KEY `members_stripe_customers_subscriptions_customer_id_foreign` (`customer_id`),
  KEY `members_stripe_customers_subscriptions_stripe_price_id_index` (`stripe_price_id`),
  CONSTRAINT `members_stripe_customers_subscriptions_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `members_stripe_customers` (`customer_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members_stripe_customers_subscriptions`
--

LOCK TABLES `members_stripe_customers_subscriptions` WRITE;
/*!40000 ALTER TABLE `members_stripe_customers_subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `members_stripe_customers_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members_subscribe_events`
--

DROP TABLE IF EXISTS `members_subscribe_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `members_subscribe_events` (
  `id` varchar(24) NOT NULL,
  `member_id` varchar(24) NOT NULL,
  `subscribed` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL,
  `source` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `members_subscribe_events_member_id_foreign` (`member_id`),
  CONSTRAINT `members_subscribe_events_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members_subscribe_events`
--

LOCK TABLES `members_subscribe_events` WRITE;
/*!40000 ALTER TABLE `members_subscribe_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `members_subscribe_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `version` varchar(70) NOT NULL,
  `currentVersion` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `migrations_name_version_unique` (`name`,`version`)
) ENGINE=InnoDB AUTO_INCREMENT=199 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'1-create-tables.js','init','4.4'),(2,'2-create-fixtures.js','init','4.4'),(3,'1-post-excerpt.js','1.3','4.4'),(4,'1-codeinjection-post.js','1.4','4.4'),(5,'1-og-twitter-post.js','1.5','4.4'),(6,'1-add-backup-client.js','1.7','4.4'),(7,'1-add-permissions-redirect.js','1.9','4.4'),(8,'1-custom-template-post.js','1.13','4.4'),(9,'2-theme-permissions.js','1.13','4.4'),(10,'1-add-webhooks-table.js','1.18','4.4'),(11,'1-webhook-permissions.js','1.19','4.4'),(12,'1-remove-settings-keys.js','1.20','4.4'),(13,'1-add-contributor-role.js','1.21','4.4'),(14,'1-multiple-authors-DDL.js','1.22','4.4'),(15,'1-multiple-authors-DML.js','1.22','4.4'),(16,'1-update-koenig-beta-html.js','1.25','4.4'),(17,'2-demo-post.js','1.25','4.4'),(18,'1-rename-amp-column.js','2.0','4.4'),(19,'2-update-posts.js','2.0','4.4'),(20,'3-remove-koenig-labs.js','2.0','4.4'),(21,'4-permalink-setting.js','2.0','4.4'),(22,'5-remove-demo-post.js','2.0','4.4'),(23,'6-replace-fixture-posts.js','2.0','4.4'),(24,'1-add-sessions-table.js','2.2','4.4'),(25,'2-add-integrations-and-api-key-tables.js','2.2','4.4'),(26,'3-insert-admin-integration-role.js','2.2','4.4'),(27,'4-insert-integration-and-api-key-permissions.js','2.2','4.4'),(28,'5-add-mobiledoc-revisions-table.js','2.2','4.4'),(29,'1-add-webhook-columns.js','2.3','4.4'),(30,'2-add-webhook-edit-permission.js','2.3','4.4'),(31,'1-add-webhook-permission-roles.js','2.6','4.4'),(32,'1-add-members-table.js','2.8','4.4'),(33,'1-remove-empty-strings.js','2.13','4.4'),(34,'1-add-actions-table.js','2.14','4.4'),(35,'2-add-actions-permissions.js','2.14','4.4'),(36,'1-add-type-column-to-integrations.js','2.15','4.4'),(37,'2-insert-zapier-integration.js','2.15','4.4'),(38,'1-add-members-perrmissions.js','2.16','4.4'),(39,'1-normalize-settings.js','2.17','4.4'),(40,'2-posts-add-canonical-url.js','2.17','4.4'),(41,'1-restore-settings-from-backup.js','2.18','4.4'),(42,'1-update-editor-permissions.js','2.21','4.4'),(43,'1-add-member-permissions-to-roles.js','2.22','4.4'),(44,'1-insert-ghost-db-backup-role.js','2.27','4.4'),(45,'2-insert-db-backup-integration.js','2.27','4.4'),(46,'3-add-subdirectory-to-relative-canonical-urls.js','2.27','4.4'),(47,'1-add-db-backup-content-permission.js','2.28','4.4'),(48,'2-add-db-backup-content-permission-to-roles.js','2.28','4.4'),(49,'3-insert-ghost-scheduler-role.js','2.28','4.4'),(50,'4-insert-scheduler-integration.js','2.28','4.4'),(51,'5-add-scheduler-permission-to-roles.js','2.28','4.4'),(52,'6-add-type-column.js','2.28','4.4'),(53,'7-populate-type-column.js','2.28','4.4'),(54,'8-remove-page-column.js','2.28','4.4'),(55,'1-add-post-page-column.js','2.29','4.4'),(56,'2-populate-post-page-column.js','2.29','4.4'),(57,'3-remove-page-type-column.js','2.29','4.4'),(58,'1-remove-name-and-password-from-members-table.js','2.31','4.4'),(59,'01-add-members-stripe-customers-table.js','2.32','4.4'),(60,'02-add-name-to-members-table.js','2.32','4.4'),(61,'01-correct-members-stripe-customers-table.js','2.33','4.4'),(62,'01-add-stripe-customers-subscriptions-table.js','2.34','4.4'),(63,'02-add-email-to-members-stripe-customers-table.js','2.34','4.4'),(64,'03-add-name-to-members-stripe-customers-table.js','2.34','4.4'),(65,'01-add-note-to-members-table.js','2.35','4.4'),(66,'01-add-self-signup-and-from address-to-members-settings.js','2.37','4.4'),(67,'01-remove-user-ghost-auth-columns.js','3.0','4.4'),(68,'02-drop-token-auth-tables.js','3.0','4.4'),(69,'03-drop-client-auth-tables.js','3.0','4.4'),(70,'04-add-posts-meta-table.js','3.0','4.4'),(71,'05-populate-posts-meta-table.js','3.0','4.4'),(72,'06-remove-posts-meta-columns.js','3.0','4.4'),(73,'07-add-posts-type-column.js','3.0','4.4'),(74,'08-populate-posts-type-column.js','3.0','4.4'),(75,'09-remove-posts-page-column.js','3.0','4.4'),(76,'10-remove-empty-strings.js','3.0','4.4'),(77,'11-update-posts-html.js','3.0','4.4'),(78,'12-populate-members-table-from-subscribers.js','3.0','4.4'),(79,'13-drop-subscribers-table.js','3.0','4.4'),(80,'14-remove-subscribers-flag.js','3.0','4.4'),(81,'01-add-send-email-when-published-to-posts.js','3.1','4.4'),(82,'02-add-email-subject-to-posts-meta.js','3.1','4.4'),(83,'03-add-email-preview-permissions.js','3.1','4.4'),(84,'04-add-subscribed-flag-to-members.js','3.1','4.4'),(85,'05-add-emails-table.js','3.1','4.4'),(86,'06-add-email-permissions.js','3.1','4.4'),(87,'07-add-uuid-field-to-members.js','3.1','4.4'),(88,'08-add-uuid-values-to-members.js','3.1','4.4'),(89,'09-add-further-email-permissions.js','3.1','4.4'),(90,'10-add-email-error-data-column.js','3.1','4.4'),(91,'01-add-cancel-at-period-end-to-subscriptions.js','3.2','4.4'),(92,'1-add-labels-table.js','3.6','4.4'),(93,'2-add-members-labels-table.js','3.6','4.4'),(94,'3-add-labels-permissions.js','3.6','4.4'),(95,'01-fix-incorrect-member-labels-foreign-keys.js','3.7','4.4'),(96,'01-add-geolocation-to-members.js','3.8','4.4'),(97,'01-add-member-sigin-url-permissions.js','3.9','4.4'),(98,'01-remove-broken-complimentary-plan-from-members-settings.js','3.11','4.4'),(99,'01-add-identity-permission.js','3.12','4.4'),(100,'02-remove-legacy-is-paid-flag-from-settings.js','3.12','4.4'),(101,'01-add-email-preview-permissions-to-roles.js','3.18','4.4'),(102,'02-add-members_stripe_connect-auth-permissions.js','3.18','4.4'),(103,'01-update-member-from-email-address.js','3.19','4.4'),(104,'01-removed-legacy-values-from-settings-table.js','3.22','4.4'),(105,'02-settings-key-renames.js','3.22','4.4'),(106,'03-add-group-and-flags-to-settings.js','3.22','4.4'),(107,'04-populate-settings-groups-and-flags.js','3.22','4.4'),(108,'05-migrate-members-subscription-settings.js','3.22','4.4'),(109,'06-migrate-stripe-connect-settings.js','3.22','4.4'),(110,'07-update-type-for-settings.js','3.22','4.4'),(111,'01-migrate-bulk-email-settings.js','3.23','4.4'),(112,'02-remove-bulk-email-settings.js','3.23','4.4'),(113,'03-update-portal-button-setting.js','3.23','4.4'),(114,'04-add-meta-columns-to-tags-table.js','3.23','4.4'),(115,'01-populate-group-for-new-portal-settings.js','3.24','4.4'),(116,'01-add-members-stripe-webhook-settings.js','3.25','4.4'),(117,'01-add-amp-gtag-id-setting.js','3.26','4.4'),(118,'01-remove-duplicate-subscriptions.js','3.29','4.4'),(119,'02-remove-duplicate-customers.js','3.29','4.4'),(120,'03-remove-orphaned-customers.js','3.29','4.4'),(121,'04-remove-orphaned-subscriptions.js','3.29','4.4'),(122,'05-add-member-constraints.js','3.29','4.4'),(123,'01-add-member-signin-url-permission-roles.js','3.30','4.4'),(124,'01-add-member-support-address-setting.js','3.32','4.4'),(125,'02-add-member-reply-address-setting.js','3.32','4.4'),(126,'03-add-routes-hash-setting.js','3.32','4.4'),(127,'01-add-email-recipients-tables.js','3.33','4.4'),(128,'01-add-tokens-table.js','3.34','4.4'),(129,'01-add-address-columns-to-emails-table.js','3.35','4.4'),(130,'01-add-snippets-table.js','3.36','4.4'),(131,'02-add-snippets-permissions.js','3.36','4.4'),(132,'01-update-portal-button-setting.js','3.37','4.4'),(133,'01-add-email-recipient-filter-column.js','3.38','4.4'),(134,'02-populate-email-recipient-filter-column.js','3.38','4.4'),(135,'03-add-recipient-filter-column.js','3.38','4.4'),(136,'04-populate-recipient-filter-column.js','3.38','4.4'),(137,'05-add-emails-track-opens-column.js','3.38','4.4'),(138,'06-add-newsletter-settings.js','3.38','4.4'),(139,'07-migrate-newsletter-settings-from-config.js','3.38','4.4'),(140,'08-repopulate-send-email-when-published-down-migration.js','3.38','4.4'),(141,'09-remove-send-email-when-published-column.js','3.38','4.4'),(142,'01-add-members-signup-redirect-settings.js','3.39','4.4'),(143,'02-add-user-id-to-api-keys-table.js','3.39','4.4'),(144,'03-add-email-track-opens-setting.js','3.39','4.4'),(145,'04-add-cancellation-reason-column.js','3.39','4.4'),(146,'05-remove-unused-columns-on-emails.js','3.39','4.4'),(147,'06-add-email-recipient-index.js','3.39','4.4'),(148,'07-add-email-recipients-event-timestamps.js','3.39','4.4'),(149,'08-add-email-stats-columns.js','3.39','4.4'),(150,'01-add-members-email-open-rate-column.js','3.40','4.4'),(151,'02-add members-email-aggregation-columns.js','3.40','4.4'),(152,'03-populate-members-email-counts.js','3.40','4.4'),(153,'01-add-firstpromoter-settings.js','3.41','4.4'),(154,'01-update-mobiledoc.js','4.0','4.4'),(155,'02-add-status-column-to-members.js','4.0','4.4'),(156,'03-populate-status-column-for-members.js','4.0','4.4'),(157,'04-drop-apps-related-tables.js','4.0','4.4'),(158,'05-add-members-subscribe-events-table.js','4.0','4.4'),(159,'06-populate-members-subscribe-events-table.js','4.0','4.4'),(160,'07-alter-unique-constraint-for-posts-slug.js','4.0','4.4'),(161,'08-add-members-login-events-table.js','4.0','4.4'),(162,'09-add-members-email-change-events-table.js','4.0','4.4'),(163,'10-add-members-status-events-table.js','4.0','4.4'),(164,'11-add-members-paid-subscription-events-table.js','4.0','4.4'),(165,'12-delete-apps-related-settings-keys.js','4.0','4.4'),(166,'13-add-members-payment-events-table.js','4.0','4.4'),(167,'14-remove-orphaned-stripe-records.js','4.0','4.4'),(168,'15-add-frontmatter-column-to-meta.js','4.0','4.4'),(169,'16-refactor-slack-setting.js','4.0','4.4'),(170,'17-populate-members-status-events-table.js','4.0','4.4'),(171,'18-transform-urls-absolute-to-transform-ready.js','4.0','4.4'),(172,'19-remove-labs-members-setting.js','4.0','4.4'),(173,'20-refactor-unsplash-setting.js','4.0','4.4'),(174,'21-sanitize-email-batches-provider-id.js','4.0','4.4'),(175,'22-solve-orphaned-webhooks.js','4.0','4.4'),(176,'23-regenerate-posts-html.js','4.0','4.4'),(177,'24-add-missing-email-permissions.js','4.0','4.4'),(178,'25-populate-members-paid-subscription-events-table.js','4.0','4.4'),(179,'26-add-cascade-on-delete.js','4.0','4.4'),(180,'27-add-primary-key-brute-migrations-lock.js','4.0','4.4'),(181,'28-add-webhook-intergrations-foreign-key.js','4.0','4.4'),(182,'29-fix-foreign-key-for-members-stripe-customers-subscriptions.js','4.0','4.4'),(183,'30-set-default-accent-color.js','4.0','4.4'),(184,'01-fix-backup-content-permission-typo.js','4.1','4.4'),(185,'02-add-unique-constraint-for-member-stripe-tables.js','4.1','4.4'),(186,'01-fix-incorrect-mrr-delta-events.js','4.2','4.4'),(187,'01-add-products-table.js','4.3','4.4'),(188,'02-add-members-products-table.js','4.3','4.4'),(189,'03-add-default-product.js','4.3','4.4'),(190,'04-attach-members-to-product.js','4.3','4.4'),(191,'05-add-stripe-products-table.js','4.3','4.4'),(192,'06-add-stripe-prices-table.js','4.3','4.4'),(193,'07-add-products-permissions.js','4.3','4.4'),(194,'08-migrate-members-signup-setting.js','4.3','4.4'),(195,'09-add-price-id-column-to-subscriptions-table.js','4.3','4.4'),(196,'10-populate-stripe-price-id-in-subscriptions.js','4.3','4.4'),(197,'01-restore-free-members-signup-setting-from-backup.js','4.4','4.4'),(198,'02-migrate-members-signup-access.js','4.4','4.4');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations_lock`
--

DROP TABLE IF EXISTS `migrations_lock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations_lock` (
  `lock_key` varchar(191) NOT NULL,
  `locked` tinyint(1) DEFAULT 0,
  `acquired_at` datetime DEFAULT NULL,
  `released_at` datetime DEFAULT NULL,
  PRIMARY KEY (`lock_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations_lock`
--

LOCK TABLES `migrations_lock` WRITE;
/*!40000 ALTER TABLE `migrations_lock` DISABLE KEYS */;
INSERT INTO `migrations_lock` VALUES ('km01',0,'2021-05-05 00:51:36','2021-05-05 00:51:41');
/*!40000 ALTER TABLE `migrations_lock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mobiledoc_revisions`
--

DROP TABLE IF EXISTS `mobiledoc_revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mobiledoc_revisions` (
  `id` varchar(24) NOT NULL,
  `post_id` varchar(24) NOT NULL,
  `mobiledoc` longtext DEFAULT NULL,
  `created_at_ts` bigint(20) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mobiledoc_revisions_post_id_index` (`post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mobiledoc_revisions`
--

LOCK TABLES `mobiledoc_revisions` WRITE;
/*!40000 ALTER TABLE `mobiledoc_revisions` DISABLE KEYS */;
INSERT INTO `mobiledoc_revisions` VALUES ('6091ef6d517db00001e5383a','6091ec1c517db00001e536ed','{\"version\":\"0.3.1\",\"atoms\":[],\"cards\":[[\"hr\",{}],[\"hr\",{}]],\"markups\":[[\"strong\"],[\"a\",[\"href\",\"http://localhost:8080/design/\"]],[\"a\",[\"href\",\"http://localhost:8080/write/\"]],[\"a\",[\"href\",\"http://localhost:8080/portal/\"]],[\"a\",[\"href\",\"http://localhost:8080/sell/\"]],[\"a\",[\"href\",\"http://localhost:8080/grow/\"]],[\"a\",[\"href\",\"http://localhost:8080/integrations/\"]],[\"a\",[\"href\",\"https://ghost.org/blog/\"]],[\"a\",[\"href\",\"https://ghost.org/pricing/\"]],[\"em\"],[\"a\",[\"href\",\"https://forum.ghost.org\"]]],\"sections\":[[1,\"p\",[[0,[0],1,\"Hey there\"],[0,[],0,\", welcome to your new home on the web! \"]]],[1,\"p\",[[0,[],0,\"Unlike social networks, this one is all yours. Publish your work on a custom domain, invite your audience to subscribe, send them new content by email newsletter, and offer premium subscriptions to generate sustainable recurring revenue to fund your work. \"]]],[1,\"p\",[[0,[],0,\"Ghost is an independent, open source app, which means you can customize absolutely everything. Inside the admin area, you\'ll find straightforward controls for changing themes, colors, navigation, logos and settings — so you can set your site up just how you like it. No technical knowledge required.\"]]],[1,\"p\",[[0,[],0,\"If you\'re feeling a little more adventurous, there\'s really no limit to what\'s possible. With just a little bit of HTML and CSS you can modify or build your very own theme from scratch, or connect to Zapier to explore advanced integrations. Advanced developers can go even further and build entirely custom workflows using the Ghost API.\"]]],[1,\"p\",[[0,[],0,\"This level of customization means that Ghost grows with you. It\'s easy to get started, but there\'s always another level of what\'s possible. So, you won\'t find yourself outgrowing the app in a few months time and wishing you\'d chosen something more powerful!\"]]],[10,0],[1,\"p\",[[0,[],0,\"For now, you\'re probably just wondering what to do first. To help get you going as quickly as possible, we\'ve populated your site with starter content (like this post!) covering all the key concepts and features of the product.\"]]],[1,\"p\",[[0,[],0,\"You\'ll find an outline of all the different topics below, with links to each section so you can explore the parts that interest you most.\"]]],[1,\"p\",[[0,[],0,\"Once you\'re ready to begin publishing and want to clear out these starter posts, you can delete the \\\"Ghost\\\" staff user. Deleting an author will automatically remove all of their posts, leaving you with a clean blank canvas.\"]]],[1,\"h2\",[[0,[],0,\"Your guide to Ghost\"]]],[3,\"ul\",[[[0,[1],1,\"Customizing your brand and site settings\"]],[[0,[2],1,\"Writing & managing content, an advanced guide for creators\"]],[[0,[3],1,\"Building your audience with subscriber signups\"]],[[0,[4],1,\"Selling premium memberships with recurring revenue\"]],[[0,[5],1,\"How to grow your business around an audience\"]],[[0,[6],1,\"Setting up custom integrations and apps\"]]]],[1,\"p\",[[0,[],0,\"If you get through all those and you\'re hungry for more, you can find an extensive library of content for creators over on \"],[0,[7],1,\"the Ghost blog\"],[0,[],0,\".\"]]],[10,1],[1,\"h2\",[[0,[],0,\"Getting help\"]]],[1,\"p\",[[0,[],0,\"If you need help, \"],[0,[8],1,\"Ghost(Pro)\"],[0,[],0,\" customers can always reach our full-time support team by clicking on the \"],[0,[9],1,\"Ghost(Pro)\"],[0,[],0,\" link inside their admin panel.\"]]],[1,\"p\",[[0,[],0,\"If you\'re a developer working with the codebase in a self-managed install, check out our \"],[0,[10],1,\"developer community forum\"],[0,[],0,\" to chat with other users.\"]]],[1,\"p\",[[0,[],0,\"Have fun!\"]]]],\"ghostVersion\":\"4.0\"}',1620176749855,'2021-05-05 01:05:49'),('6091ef6d517db00001e5383b','6091ec1c517db00001e536ed','{\"version\":\"0.3.1\",\"atoms\":[],\"cards\":[[\"hr\",{}],[\"hr\",{}]],\"markups\":[[\"strong\"],[\"a\",[\"href\",\"http://localhost:8080/design/\"]],[\"a\",[\"href\",\"http://localhost:8080/write/\"]],[\"a\",[\"href\",\"http://localhost:8080/portal/\"]],[\"a\",[\"href\",\"http://localhost:8080/sell/\"]],[\"a\",[\"href\",\"http://localhost:8080/grow/\"]],[\"a\",[\"href\",\"http://localhost:8080/integrations/\"]],[\"a\",[\"href\",\"https://ghost.org/blog/\"]],[\"a\",[\"href\",\"https://ghost.org/pricing/\"]],[\"em\"],[\"a\",[\"href\",\"https://forum.ghost.org\"]]],\"sections\":[[1,\"p\",[[0,[0],1,\"Hey therex\"],[0,[],0,\", welcome to your new home on the web! \"]]],[1,\"p\",[[0,[],0,\"Unlike social networks, this one is all yours. Publish your work on a custom domain, invite your audience to subscribe, send them new content by email newsletter, and offer premium subscriptions to generate sustainable recurring revenue to fund your work. \"]]],[1,\"p\",[[0,[],0,\"Ghost is an independent, open source app, which means you can customize absolutely everything. Inside the admin area, you\'ll find straightforward controls for changing themes, colors, navigation, logos and settings — so you can set your site up just how you like it. No technical knowledge required.\"]]],[1,\"p\",[[0,[],0,\"If you\'re feeling a little more adventurous, there\'s really no limit to what\'s possible. With just a little bit of HTML and CSS you can modify or build your very own theme from scratch, or connect to Zapier to explore advanced integrations. Advanced developers can go even further and build entirely custom workflows using the Ghost API.\"]]],[1,\"p\",[[0,[],0,\"This level of customization means that Ghost grows with you. It\'s easy to get started, but there\'s always another level of what\'s possible. So, you won\'t find yourself outgrowing the app in a few months time and wishing you\'d chosen something more powerful!\"]]],[10,0],[1,\"p\",[[0,[],0,\"For now, you\'re probably just wondering what to do first. To help get you going as quickly as possible, we\'ve populated your site with starter content (like this post!) covering all the key concepts and features of the product.\"]]],[1,\"p\",[[0,[],0,\"You\'ll find an outline of all the different topics below, with links to each section so you can explore the parts that interest you most.\"]]],[1,\"p\",[[0,[],0,\"Once you\'re ready to begin publishing and want to clear out these starter posts, you can delete the \\\"Ghost\\\" staff user. Deleting an author will automatically remove all of their posts, leaving you with a clean blank canvas.\"]]],[1,\"h2\",[[0,[],0,\"Your guide to Ghost\"]]],[3,\"ul\",[[[0,[1],1,\"Customizing your brand and site settings\"]],[[0,[2],1,\"Writing & managing content, an advanced guide for creators\"]],[[0,[3],1,\"Building your audience with subscriber signups\"]],[[0,[4],1,\"Selling premium memberships with recurring revenue\"]],[[0,[5],1,\"How to grow your business around an audience\"]],[[0,[6],1,\"Setting up custom integrations and apps\"]]]],[1,\"p\",[[0,[],0,\"If you get through all those and you\'re hungry for more, you can find an extensive library of content for creators over on \"],[0,[7],1,\"the Ghost blog\"],[0,[],0,\".\"]]],[10,1],[1,\"h2\",[[0,[],0,\"Getting help\"]]],[1,\"p\",[[0,[],0,\"If you need help, \"],[0,[8],1,\"Ghost(Pro)\"],[0,[],0,\" customers can always reach our full-time support team by clicking on the \"],[0,[9],1,\"Ghost(Pro)\"],[0,[],0,\" link inside their admin panel.\"]]],[1,\"p\",[[0,[],0,\"If you\'re a developer working with the codebase in a self-managed install, check out our \"],[0,[10],1,\"developer community forum\"],[0,[],0,\" to chat with other users.\"]]],[1,\"p\",[[0,[],0,\"Have fun!\"]]]],\"ghostVersion\":\"4.0\"}',1620176749856,'2021-05-05 01:05:49');
/*!40000 ALTER TABLE `mobiledoc_revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` varchar(24) NOT NULL,
  `name` varchar(50) NOT NULL,
  `object_type` varchar(50) NOT NULL,
  `action_type` varchar(50) NOT NULL,
  `object_id` varchar(24) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `created_by` varchar(24) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` varchar(24) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES ('6091ec1c517db00001e5368b','Export database','db','exportContent',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e5368c','Import database','db','importContent',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e5368d','Delete all content','db','deleteAllContent',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e5368e','Send mail','mail','send',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e5368f','Browse notifications','notification','browse',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e53690','Add notifications','notification','add',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e53691','Delete notifications','notification','destroy',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e53692','Browse posts','post','browse',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e53693','Read posts','post','read',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e53694','Edit posts','post','edit',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e53695','Add posts','post','add',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e53696','Delete posts','post','destroy',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e53697','Browse settings','setting','browse',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e53698','Read settings','setting','read',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e53699','Edit settings','setting','edit',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e5369a','Generate slugs','slug','generate',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e5369b','Browse tags','tag','browse',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e5369c','Read tags','tag','read',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e5369d','Edit tags','tag','edit',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e5369e','Add tags','tag','add',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e5369f','Delete tags','tag','destroy',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536a0','Browse themes','theme','browse',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536a1','Edit themes','theme','edit',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536a2','Activate themes','theme','activate',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536a3','Upload themes','theme','add',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536a4','Download themes','theme','read',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536a5','Delete themes','theme','destroy',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536a6','Browse users','user','browse',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536a7','Read users','user','read',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536a8','Edit users','user','edit',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536a9','Add users','user','add',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536aa','Delete users','user','destroy',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536ab','Assign a role','role','assign',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536ac','Browse roles','role','browse',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536ad','Browse invites','invite','browse',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536ae','Read invites','invite','read',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536af','Edit invites','invite','edit',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536b0','Add invites','invite','add',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536b1','Delete invites','invite','destroy',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536b2','Download redirects','redirect','download',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536b3','Upload redirects','redirect','upload',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536b4','Add webhooks','webhook','add',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536b5','Edit webhooks','webhook','edit',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536b6','Delete webhooks','webhook','destroy',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536b7','Browse integrations','integration','browse',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536b8','Read integrations','integration','read',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536b9','Edit integrations','integration','edit',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536ba','Add integrations','integration','add',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536bb','Delete integrations','integration','destroy',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536bc','Browse API keys','api_key','browse',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536bd','Read API keys','api_key','read',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536be','Edit API keys','api_key','edit',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536bf','Add API keys','api_key','add',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536c0','Delete API keys','api_key','destroy',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536c1','Browse Actions','action','browse',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536c2','Browse Members','member','browse',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536c3','Read Members','member','read',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536c4','Edit Members','member','edit',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536c5','Add Members','member','add',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536c6','Delete Members','member','destroy',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536c7','Browse Products','product','browse',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536c8','Read Products','product','read',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536c9','Edit Products','product','edit',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536ca','Add Products','product','add',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536cb','Delete Products','product','destroy',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536cc','Publish posts','post','publish',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536cd','Backup database','db','backupContent',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536ce','Email preview','email_preview','read',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536cf','Send test email','email_preview','sendTestEmail',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536d0','Browse emails','email','browse',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536d1','Read emails','email','read',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536d2','Retry emails','email','retry',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536d3','Browse labels','label','browse',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536d4','Read labels','label','read',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536d5','Edit labels','label','edit',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536d6','Add labels','label','add',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536d7','Delete labels','label','destroy',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536d8','Read member signin urls','member_signin_url','read',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536d9','Read identities','identity','read',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536da','Auth Stripe Connect for Members','members_stripe_connect','auth',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536db','Browse snippets','snippet','browse',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536dc','Read snippets','snippet','read',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536dd','Edit snippets','snippet','edit',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536de','Add snippets','snippet','add',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1'),('6091ec1c517db00001e536df','Delete snippets','snippet','destroy',NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions_roles`
--

DROP TABLE IF EXISTS `permissions_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions_roles` (
  `id` varchar(24) NOT NULL,
  `role_id` varchar(24) NOT NULL,
  `permission_id` varchar(24) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions_roles`
--

LOCK TABLES `permissions_roles` WRITE;
/*!40000 ALTER TABLE `permissions_roles` DISABLE KEYS */;
INSERT INTO `permissions_roles` VALUES ('6091ec1d517db00001e536fd','6091ec1b517db00001e53683','6091ec1c517db00001e5368b'),('6091ec1d517db00001e536fe','6091ec1b517db00001e53683','6091ec1c517db00001e5368c'),('6091ec1d517db00001e536ff','6091ec1b517db00001e53683','6091ec1c517db00001e5368d'),('6091ec1d517db00001e53700','6091ec1b517db00001e53683','6091ec1c517db00001e536cd'),('6091ec1d517db00001e53701','6091ec1b517db00001e53683','6091ec1c517db00001e5368e'),('6091ec1d517db00001e53702','6091ec1b517db00001e53683','6091ec1c517db00001e5368f'),('6091ec1d517db00001e53703','6091ec1b517db00001e53683','6091ec1c517db00001e53690'),('6091ec1d517db00001e53704','6091ec1b517db00001e53683','6091ec1c517db00001e53691'),('6091ec1d517db00001e53705','6091ec1b517db00001e53683','6091ec1c517db00001e53692'),('6091ec1d517db00001e53706','6091ec1b517db00001e53683','6091ec1c517db00001e53693'),('6091ec1d517db00001e53707','6091ec1b517db00001e53683','6091ec1c517db00001e53694'),('6091ec1d517db00001e53708','6091ec1b517db00001e53683','6091ec1c517db00001e53695'),('6091ec1d517db00001e53709','6091ec1b517db00001e53683','6091ec1c517db00001e53696'),('6091ec1d517db00001e5370a','6091ec1b517db00001e53683','6091ec1c517db00001e536cc'),('6091ec1d517db00001e5370b','6091ec1b517db00001e53683','6091ec1c517db00001e53697'),('6091ec1d517db00001e5370c','6091ec1b517db00001e53683','6091ec1c517db00001e53698'),('6091ec1d517db00001e5370d','6091ec1b517db00001e53683','6091ec1c517db00001e53699'),('6091ec1d517db00001e5370e','6091ec1b517db00001e53683','6091ec1c517db00001e5369a'),('6091ec1d517db00001e5370f','6091ec1b517db00001e53683','6091ec1c517db00001e5369b'),('6091ec1d517db00001e53710','6091ec1b517db00001e53683','6091ec1c517db00001e5369c'),('6091ec1d517db00001e53711','6091ec1b517db00001e53683','6091ec1c517db00001e5369d'),('6091ec1d517db00001e53712','6091ec1b517db00001e53683','6091ec1c517db00001e5369e'),('6091ec1d517db00001e53713','6091ec1b517db00001e53683','6091ec1c517db00001e5369f'),('6091ec1d517db00001e53714','6091ec1b517db00001e53683','6091ec1c517db00001e536a0'),('6091ec1d517db00001e53715','6091ec1b517db00001e53683','6091ec1c517db00001e536a1'),('6091ec1d517db00001e53716','6091ec1b517db00001e53683','6091ec1c517db00001e536a2'),('6091ec1d517db00001e53717','6091ec1b517db00001e53683','6091ec1c517db00001e536a3'),('6091ec1d517db00001e53718','6091ec1b517db00001e53683','6091ec1c517db00001e536a4'),('6091ec1d517db00001e53719','6091ec1b517db00001e53683','6091ec1c517db00001e536a5'),('6091ec1d517db00001e5371a','6091ec1b517db00001e53683','6091ec1c517db00001e536a6'),('6091ec1d517db00001e5371b','6091ec1b517db00001e53683','6091ec1c517db00001e536a7'),('6091ec1d517db00001e5371c','6091ec1b517db00001e53683','6091ec1c517db00001e536a8'),('6091ec1d517db00001e5371d','6091ec1b517db00001e53683','6091ec1c517db00001e536a9'),('6091ec1d517db00001e5371e','6091ec1b517db00001e53683','6091ec1c517db00001e536aa'),('6091ec1d517db00001e5371f','6091ec1b517db00001e53683','6091ec1c517db00001e536ab'),('6091ec1d517db00001e53720','6091ec1b517db00001e53683','6091ec1c517db00001e536ac'),('6091ec1d517db00001e53721','6091ec1b517db00001e53683','6091ec1c517db00001e536ad'),('6091ec1d517db00001e53722','6091ec1b517db00001e53683','6091ec1c517db00001e536ae'),('6091ec1d517db00001e53723','6091ec1b517db00001e53683','6091ec1c517db00001e536af'),('6091ec1d517db00001e53724','6091ec1b517db00001e53683','6091ec1c517db00001e536b0'),('6091ec1d517db00001e53725','6091ec1b517db00001e53683','6091ec1c517db00001e536b1'),('6091ec1d517db00001e53726','6091ec1b517db00001e53683','6091ec1c517db00001e536b2'),('6091ec1d517db00001e53727','6091ec1b517db00001e53683','6091ec1c517db00001e536b3'),('6091ec1d517db00001e53728','6091ec1b517db00001e53683','6091ec1c517db00001e536b4'),('6091ec1d517db00001e53729','6091ec1b517db00001e53683','6091ec1c517db00001e536b5'),('6091ec1d517db00001e5372a','6091ec1b517db00001e53683','6091ec1c517db00001e536b6'),('6091ec1d517db00001e5372b','6091ec1b517db00001e53683','6091ec1c517db00001e536b7'),('6091ec1d517db00001e5372c','6091ec1b517db00001e53683','6091ec1c517db00001e536b8'),('6091ec1d517db00001e5372d','6091ec1b517db00001e53683','6091ec1c517db00001e536b9'),('6091ec1d517db00001e5372e','6091ec1b517db00001e53683','6091ec1c517db00001e536ba'),('6091ec1d517db00001e5372f','6091ec1b517db00001e53683','6091ec1c517db00001e536bb'),('6091ec1d517db00001e53730','6091ec1b517db00001e53683','6091ec1c517db00001e536bc'),('6091ec1d517db00001e53731','6091ec1b517db00001e53683','6091ec1c517db00001e536bd'),('6091ec1d517db00001e53732','6091ec1b517db00001e53683','6091ec1c517db00001e536be'),('6091ec1d517db00001e53733','6091ec1b517db00001e53683','6091ec1c517db00001e536bf'),('6091ec1d517db00001e53734','6091ec1b517db00001e53683','6091ec1c517db00001e536c0'),('6091ec1d517db00001e53735','6091ec1b517db00001e53683','6091ec1c517db00001e536c1'),('6091ec1d517db00001e53736','6091ec1b517db00001e53683','6091ec1c517db00001e536c2'),('6091ec1d517db00001e53737','6091ec1b517db00001e53683','6091ec1c517db00001e536c3'),('6091ec1d517db00001e53738','6091ec1b517db00001e53683','6091ec1c517db00001e536c4'),('6091ec1d517db00001e53739','6091ec1b517db00001e53683','6091ec1c517db00001e536c5'),('6091ec1d517db00001e5373a','6091ec1b517db00001e53683','6091ec1c517db00001e536c6'),('6091ec1d517db00001e5373b','6091ec1b517db00001e53683','6091ec1c517db00001e536c7'),('6091ec1d517db00001e5373c','6091ec1b517db00001e53683','6091ec1c517db00001e536c8'),('6091ec1d517db00001e5373d','6091ec1b517db00001e53683','6091ec1c517db00001e536c9'),('6091ec1d517db00001e5373e','6091ec1b517db00001e53683','6091ec1c517db00001e536ca'),('6091ec1d517db00001e5373f','6091ec1b517db00001e53683','6091ec1c517db00001e536cb'),('6091ec1d517db00001e53740','6091ec1b517db00001e53683','6091ec1c517db00001e536d3'),('6091ec1d517db00001e53741','6091ec1b517db00001e53683','6091ec1c517db00001e536d4'),('6091ec1d517db00001e53742','6091ec1b517db00001e53683','6091ec1c517db00001e536d5'),('6091ec1d517db00001e53743','6091ec1b517db00001e53683','6091ec1c517db00001e536d6'),('6091ec1d517db00001e53744','6091ec1b517db00001e53683','6091ec1c517db00001e536d7'),('6091ec1d517db00001e53745','6091ec1b517db00001e53683','6091ec1c517db00001e536ce'),('6091ec1d517db00001e53746','6091ec1b517db00001e53683','6091ec1c517db00001e536cf'),('6091ec1d517db00001e53747','6091ec1b517db00001e53683','6091ec1c517db00001e536d0'),('6091ec1d517db00001e53748','6091ec1b517db00001e53683','6091ec1c517db00001e536d1'),('6091ec1d517db00001e53749','6091ec1b517db00001e53683','6091ec1c517db00001e536d2'),('6091ec1d517db00001e5374a','6091ec1b517db00001e53683','6091ec1c517db00001e536d8'),('6091ec1d517db00001e5374b','6091ec1b517db00001e53683','6091ec1c517db00001e536db'),('6091ec1d517db00001e5374c','6091ec1b517db00001e53683','6091ec1c517db00001e536dc'),('6091ec1d517db00001e5374d','6091ec1b517db00001e53683','6091ec1c517db00001e536dd'),('6091ec1d517db00001e5374e','6091ec1b517db00001e53683','6091ec1c517db00001e536de'),('6091ec1d517db00001e5374f','6091ec1b517db00001e53683','6091ec1c517db00001e536df'),('6091ec1d517db00001e53750','6091ec1b517db00001e53689','6091ec1c517db00001e5368b'),('6091ec1d517db00001e53751','6091ec1b517db00001e53689','6091ec1c517db00001e5368c'),('6091ec1d517db00001e53752','6091ec1b517db00001e53689','6091ec1c517db00001e5368d'),('6091ec1d517db00001e53753','6091ec1b517db00001e53689','6091ec1c517db00001e536cd'),('6091ec1d517db00001e53754','6091ec1c517db00001e5368a','6091ec1c517db00001e536cc'),('6091ec1d517db00001e53755','6091ec1b517db00001e53688','6091ec1c517db00001e5368e'),('6091ec1d517db00001e53756','6091ec1b517db00001e53688','6091ec1c517db00001e5368f'),('6091ec1d517db00001e53757','6091ec1b517db00001e53688','6091ec1c517db00001e53690'),('6091ec1d517db00001e53758','6091ec1b517db00001e53688','6091ec1c517db00001e53691'),('6091ec1d517db00001e53759','6091ec1b517db00001e53688','6091ec1c517db00001e53692'),('6091ec1d517db00001e5375a','6091ec1b517db00001e53688','6091ec1c517db00001e53693'),('6091ec1d517db00001e5375b','6091ec1b517db00001e53688','6091ec1c517db00001e53694'),('6091ec1d517db00001e5375c','6091ec1b517db00001e53688','6091ec1c517db00001e53695'),('6091ec1d517db00001e5375d','6091ec1b517db00001e53688','6091ec1c517db00001e53696'),('6091ec1d517db00001e5375e','6091ec1b517db00001e53688','6091ec1c517db00001e536cc'),('6091ec1d517db00001e5375f','6091ec1b517db00001e53688','6091ec1c517db00001e53697'),('6091ec1d517db00001e53760','6091ec1b517db00001e53688','6091ec1c517db00001e53698'),('6091ec1d517db00001e53761','6091ec1b517db00001e53688','6091ec1c517db00001e53699'),('6091ec1d517db00001e53762','6091ec1b517db00001e53688','6091ec1c517db00001e5369a'),('6091ec1d517db00001e53763','6091ec1b517db00001e53688','6091ec1c517db00001e5369b'),('6091ec1d517db00001e53764','6091ec1b517db00001e53688','6091ec1c517db00001e5369c'),('6091ec1d517db00001e53765','6091ec1b517db00001e53688','6091ec1c517db00001e5369d'),('6091ec1d517db00001e53766','6091ec1b517db00001e53688','6091ec1c517db00001e5369e'),('6091ec1d517db00001e53767','6091ec1b517db00001e53688','6091ec1c517db00001e5369f'),('6091ec1d517db00001e53768','6091ec1b517db00001e53688','6091ec1c517db00001e536a0'),('6091ec1d517db00001e53769','6091ec1b517db00001e53688','6091ec1c517db00001e536a1'),('6091ec1d517db00001e5376a','6091ec1b517db00001e53688','6091ec1c517db00001e536a2'),('6091ec1d517db00001e5376b','6091ec1b517db00001e53688','6091ec1c517db00001e536a3'),('6091ec1d517db00001e5376c','6091ec1b517db00001e53688','6091ec1c517db00001e536a4'),('6091ec1d517db00001e5376d','6091ec1b517db00001e53688','6091ec1c517db00001e536a5'),('6091ec1d517db00001e5376e','6091ec1b517db00001e53688','6091ec1c517db00001e536a6'),('6091ec1d517db00001e5376f','6091ec1b517db00001e53688','6091ec1c517db00001e536a7'),('6091ec1d517db00001e53770','6091ec1b517db00001e53688','6091ec1c517db00001e536a8'),('6091ec1d517db00001e53771','6091ec1b517db00001e53688','6091ec1c517db00001e536a9'),('6091ec1d517db00001e53772','6091ec1b517db00001e53688','6091ec1c517db00001e536aa'),('6091ec1d517db00001e53773','6091ec1b517db00001e53688','6091ec1c517db00001e536ab'),('6091ec1d517db00001e53774','6091ec1b517db00001e53688','6091ec1c517db00001e536ac'),('6091ec1d517db00001e53775','6091ec1b517db00001e53688','6091ec1c517db00001e536ad'),('6091ec1d517db00001e53776','6091ec1b517db00001e53688','6091ec1c517db00001e536ae'),('6091ec1d517db00001e53777','6091ec1b517db00001e53688','6091ec1c517db00001e536af'),('6091ec1d517db00001e53778','6091ec1b517db00001e53688','6091ec1c517db00001e536b0'),('6091ec1d517db00001e53779','6091ec1b517db00001e53688','6091ec1c517db00001e536b1'),('6091ec1d517db00001e5377a','6091ec1b517db00001e53688','6091ec1c517db00001e536b2'),('6091ec1d517db00001e5377b','6091ec1b517db00001e53688','6091ec1c517db00001e536b3'),('6091ec1d517db00001e5377c','6091ec1b517db00001e53688','6091ec1c517db00001e536b4'),('6091ec1d517db00001e5377d','6091ec1b517db00001e53688','6091ec1c517db00001e536b5'),('6091ec1d517db00001e5377e','6091ec1b517db00001e53688','6091ec1c517db00001e536b6'),('6091ec1d517db00001e5377f','6091ec1b517db00001e53688','6091ec1c517db00001e536c1'),('6091ec1d517db00001e53780','6091ec1b517db00001e53688','6091ec1c517db00001e536c2'),('6091ec1d517db00001e53781','6091ec1b517db00001e53688','6091ec1c517db00001e536c3'),('6091ec1d517db00001e53782','6091ec1b517db00001e53688','6091ec1c517db00001e536c4'),('6091ec1d517db00001e53783','6091ec1b517db00001e53688','6091ec1c517db00001e536c5'),('6091ec1d517db00001e53784','6091ec1b517db00001e53688','6091ec1c517db00001e536c6'),('6091ec1d517db00001e53785','6091ec1b517db00001e53688','6091ec1c517db00001e536d3'),('6091ec1d517db00001e53786','6091ec1b517db00001e53688','6091ec1c517db00001e536d4'),('6091ec1d517db00001e53787','6091ec1b517db00001e53688','6091ec1c517db00001e536d5'),('6091ec1d517db00001e53788','6091ec1b517db00001e53688','6091ec1c517db00001e536d6'),('6091ec1d517db00001e53789','6091ec1b517db00001e53688','6091ec1c517db00001e536d7'),('6091ec1d517db00001e5378a','6091ec1b517db00001e53688','6091ec1c517db00001e536ce'),('6091ec1d517db00001e5378b','6091ec1b517db00001e53688','6091ec1c517db00001e536cf'),('6091ec1d517db00001e5378c','6091ec1b517db00001e53688','6091ec1c517db00001e536d0'),('6091ec1d517db00001e5378d','6091ec1b517db00001e53688','6091ec1c517db00001e536d1'),('6091ec1d517db00001e5378e','6091ec1b517db00001e53688','6091ec1c517db00001e536d2'),('6091ec1d517db00001e5378f','6091ec1b517db00001e53688','6091ec1c517db00001e536db'),('6091ec1d517db00001e53790','6091ec1b517db00001e53688','6091ec1c517db00001e536dc'),('6091ec1d517db00001e53791','6091ec1b517db00001e53688','6091ec1c517db00001e536dd'),('6091ec1d517db00001e53792','6091ec1b517db00001e53688','6091ec1c517db00001e536de'),('6091ec1d517db00001e53793','6091ec1b517db00001e53688','6091ec1c517db00001e536df'),('6091ec1d517db00001e53794','6091ec1b517db00001e53684','6091ec1c517db00001e5368f'),('6091ec1d517db00001e53795','6091ec1b517db00001e53684','6091ec1c517db00001e53690'),('6091ec1d517db00001e53796','6091ec1b517db00001e53684','6091ec1c517db00001e53691'),('6091ec1d517db00001e53797','6091ec1b517db00001e53684','6091ec1c517db00001e53692'),('6091ec1d517db00001e53798','6091ec1b517db00001e53684','6091ec1c517db00001e53693'),('6091ec1d517db00001e53799','6091ec1b517db00001e53684','6091ec1c517db00001e53694'),('6091ec1d517db00001e5379a','6091ec1b517db00001e53684','6091ec1c517db00001e53695'),('6091ec1d517db00001e5379b','6091ec1b517db00001e53684','6091ec1c517db00001e53696'),('6091ec1d517db00001e5379c','6091ec1b517db00001e53684','6091ec1c517db00001e536cc'),('6091ec1d517db00001e5379d','6091ec1b517db00001e53684','6091ec1c517db00001e53697'),('6091ec1d517db00001e5379e','6091ec1b517db00001e53684','6091ec1c517db00001e53698'),('6091ec1d517db00001e5379f','6091ec1b517db00001e53684','6091ec1c517db00001e5369a'),('6091ec1d517db00001e537a0','6091ec1b517db00001e53684','6091ec1c517db00001e5369b'),('6091ec1d517db00001e537a1','6091ec1b517db00001e53684','6091ec1c517db00001e5369c'),('6091ec1d517db00001e537a2','6091ec1b517db00001e53684','6091ec1c517db00001e5369d'),('6091ec1d517db00001e537a3','6091ec1b517db00001e53684','6091ec1c517db00001e5369e'),('6091ec1d517db00001e537a4','6091ec1b517db00001e53684','6091ec1c517db00001e5369f'),('6091ec1d517db00001e537a5','6091ec1b517db00001e53684','6091ec1c517db00001e536a6'),('6091ec1d517db00001e537a6','6091ec1b517db00001e53684','6091ec1c517db00001e536a7'),('6091ec1d517db00001e537a7','6091ec1b517db00001e53684','6091ec1c517db00001e536a8'),('6091ec1d517db00001e537a8','6091ec1b517db00001e53684','6091ec1c517db00001e536a9'),('6091ec1d517db00001e537a9','6091ec1b517db00001e53684','6091ec1c517db00001e536aa'),('6091ec1d517db00001e537aa','6091ec1b517db00001e53684','6091ec1c517db00001e536ab'),('6091ec1d517db00001e537ab','6091ec1b517db00001e53684','6091ec1c517db00001e536ac'),('6091ec1d517db00001e537ac','6091ec1b517db00001e53684','6091ec1c517db00001e536ad'),('6091ec1d517db00001e537ad','6091ec1b517db00001e53684','6091ec1c517db00001e536ae'),('6091ec1d517db00001e537ae','6091ec1b517db00001e53684','6091ec1c517db00001e536af'),('6091ec1d517db00001e537af','6091ec1b517db00001e53684','6091ec1c517db00001e536b0'),('6091ec1d517db00001e537b0','6091ec1b517db00001e53684','6091ec1c517db00001e536b1'),('6091ec1d517db00001e537b1','6091ec1b517db00001e53684','6091ec1c517db00001e536a0'),('6091ec1d517db00001e537b2','6091ec1b517db00001e53684','6091ec1c517db00001e536ce'),('6091ec1d517db00001e537b3','6091ec1b517db00001e53684','6091ec1c517db00001e536cf'),('6091ec1d517db00001e537b4','6091ec1b517db00001e53684','6091ec1c517db00001e536d0'),('6091ec1d517db00001e537b5','6091ec1b517db00001e53684','6091ec1c517db00001e536d1'),('6091ec1d517db00001e537b6','6091ec1b517db00001e53684','6091ec1c517db00001e536d2'),('6091ec1d517db00001e537b7','6091ec1b517db00001e53684','6091ec1c517db00001e536db'),('6091ec1d517db00001e537b8','6091ec1b517db00001e53684','6091ec1c517db00001e536dc'),('6091ec1d517db00001e537b9','6091ec1b517db00001e53684','6091ec1c517db00001e536dd'),('6091ec1d517db00001e537ba','6091ec1b517db00001e53684','6091ec1c517db00001e536de'),('6091ec1d517db00001e537bb','6091ec1b517db00001e53684','6091ec1c517db00001e536df'),('6091ec1d517db00001e537bc','6091ec1b517db00001e53684','6091ec1c517db00001e536c7'),('6091ec1d517db00001e537bd','6091ec1b517db00001e53684','6091ec1c517db00001e536c8'),('6091ec1d517db00001e537be','6091ec1b517db00001e53685','6091ec1c517db00001e53692'),('6091ec1d517db00001e537bf','6091ec1b517db00001e53685','6091ec1c517db00001e53693'),('6091ec1d517db00001e537c0','6091ec1b517db00001e53685','6091ec1c517db00001e53695'),('6091ec1d517db00001e537c1','6091ec1b517db00001e53685','6091ec1c517db00001e53697'),('6091ec1d517db00001e537c2','6091ec1b517db00001e53685','6091ec1c517db00001e53698'),('6091ec1d517db00001e537c3','6091ec1b517db00001e53685','6091ec1c517db00001e5369a'),('6091ec1d517db00001e537c4','6091ec1b517db00001e53685','6091ec1c517db00001e5369b'),('6091ec1d517db00001e537c5','6091ec1b517db00001e53685','6091ec1c517db00001e5369c'),('6091ec1d517db00001e537c6','6091ec1b517db00001e53685','6091ec1c517db00001e5369e'),('6091ec1d517db00001e537c7','6091ec1b517db00001e53685','6091ec1c517db00001e536a6'),('6091ec1d517db00001e537c8','6091ec1b517db00001e53685','6091ec1c517db00001e536a7'),('6091ec1d517db00001e537c9','6091ec1b517db00001e53685','6091ec1c517db00001e536ac'),('6091ec1d517db00001e537ca','6091ec1b517db00001e53685','6091ec1c517db00001e536a0'),('6091ec1d517db00001e537cb','6091ec1b517db00001e53685','6091ec1c517db00001e536ce'),('6091ec1d517db00001e537cc','6091ec1b517db00001e53685','6091ec1c517db00001e536d1'),('6091ec1d517db00001e537cd','6091ec1b517db00001e53685','6091ec1c517db00001e536db'),('6091ec1d517db00001e537ce','6091ec1b517db00001e53685','6091ec1c517db00001e536dc'),('6091ec1d517db00001e537cf','6091ec1b517db00001e53685','6091ec1c517db00001e536c7'),('6091ec1d517db00001e537d0','6091ec1b517db00001e53685','6091ec1c517db00001e536c8'),('6091ec1d517db00001e537d1','6091ec1b517db00001e53686','6091ec1c517db00001e53692'),('6091ec1d517db00001e537d2','6091ec1b517db00001e53686','6091ec1c517db00001e53693'),('6091ec1d517db00001e537d3','6091ec1b517db00001e53686','6091ec1c517db00001e53695'),('6091ec1d517db00001e537d4','6091ec1b517db00001e53686','6091ec1c517db00001e53697'),('6091ec1d517db00001e537d5','6091ec1b517db00001e53686','6091ec1c517db00001e53698'),('6091ec1d517db00001e537d6','6091ec1b517db00001e53686','6091ec1c517db00001e5369a'),('6091ec1d517db00001e537d7','6091ec1b517db00001e53686','6091ec1c517db00001e5369b'),('6091ec1d517db00001e537d8','6091ec1b517db00001e53686','6091ec1c517db00001e5369c'),('6091ec1d517db00001e537d9','6091ec1b517db00001e53686','6091ec1c517db00001e536a6'),('6091ec1d517db00001e537da','6091ec1b517db00001e53686','6091ec1c517db00001e536a7'),('6091ec1d517db00001e537db','6091ec1b517db00001e53686','6091ec1c517db00001e536ac'),('6091ec1d517db00001e537dc','6091ec1b517db00001e53686','6091ec1c517db00001e536a0'),('6091ec1d517db00001e537dd','6091ec1b517db00001e53686','6091ec1c517db00001e536ce'),('6091ec1d517db00001e537de','6091ec1b517db00001e53686','6091ec1c517db00001e536d1'),('6091ec1d517db00001e537df','6091ec1b517db00001e53686','6091ec1c517db00001e536db'),('6091ec1d517db00001e537e0','6091ec1b517db00001e53686','6091ec1c517db00001e536dc');
/*!40000 ALTER TABLE `permissions_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions_users`
--

DROP TABLE IF EXISTS `permissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions_users` (
  `id` varchar(24) NOT NULL,
  `user_id` varchar(24) NOT NULL,
  `permission_id` varchar(24) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions_users`
--

LOCK TABLES `permissions_users` WRITE;
/*!40000 ALTER TABLE `permissions_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `posts` (
  `id` varchar(24) NOT NULL,
  `uuid` varchar(36) NOT NULL,
  `title` varchar(2000) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `mobiledoc` longtext DEFAULT NULL,
  `html` longtext DEFAULT NULL,
  `comment_id` varchar(50) DEFAULT NULL,
  `plaintext` longtext DEFAULT NULL,
  `feature_image` varchar(2000) DEFAULT NULL,
  `featured` tinyint(1) NOT NULL DEFAULT 0,
  `type` varchar(50) NOT NULL DEFAULT 'post',
  `status` varchar(50) NOT NULL DEFAULT 'draft',
  `locale` varchar(6) DEFAULT NULL,
  `visibility` varchar(50) NOT NULL DEFAULT 'public',
  `email_recipient_filter` varchar(50) NOT NULL DEFAULT 'none',
  `author_id` varchar(24) NOT NULL,
  `created_at` datetime NOT NULL,
  `created_by` varchar(24) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` varchar(24) DEFAULT NULL,
  `published_at` datetime DEFAULT NULL,
  `published_by` varchar(24) DEFAULT NULL,
  `custom_excerpt` varchar(2000) DEFAULT NULL,
  `codeinjection_head` text DEFAULT NULL,
  `codeinjection_foot` text DEFAULT NULL,
  `custom_template` varchar(100) DEFAULT NULL,
  `canonical_url` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `posts_slug_type_unique` (`slug`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` VALUES ('6091ec1c517db00001e536e1','272e7dc6-b636-4df2-ad4b-affe062fcb3e','Setting up apps and custom integrations','integrations','{\"version\":\"0.3.1\",\"atoms\":[],\"cards\":[[\"image\",{\"src\":\"https://static.ghost.org/v4.0.0/images/integrations-icons.png\",\"cardWidth\":\"full\"}],[\"markdown\",{\"markdown\":\"<script src=\\\"https://zapier.com/apps/embed/widget.js?services=Ghost,-shortcm,-hubspot,-sendpulse,-noticeable,-aweber,-icontact,-facebook-pages,-github,-medium,-slack,-mailchimp,-activecampaign,-twitter,-discourse&container,-convertkit,-drip,-airtable=true&limit=5\\\"></script>\\n\"}],[\"image\",{\"src\":\"https://static.ghost.org/v4.0.0/images/iawriter-integration.png\",\"width\":2244,\"height\":936}]],\"markups\":[[\"a\",[\"href\",\"https://ghost.org/integrations/\"]],[\"strong\"]],\"sections\":[[1,\"p\",[[0,[],0,\"It\'s possible to extend your Ghost site and connect it with hundreds of the most popular apps and tools using integrations. \"]]],[1,\"p\",[[0,[],0,\"Whether you need to automatically publish new posts on social media, connect your favorite analytics tool, sync your community or embed forms into your content — our \"],[0,[0],1,\"integrations library\"],[0,[],0,\" has got it all covered with hundreds of integration tutorials.\"]]],[1,\"p\",[[0,[],0,\"Many integrations are as simple as inserting an embed by pasting a link, or copying a snippet of code directly from an app and pasting it into Ghost. Our integration tutorials are used by creators of all kinds to get apps and integrations up and running in no time — no technical knowledge required.\"]]],[10,0],[1,\"h2\",[[0,[],0,\"Zapier\"]]],[1,\"p\",[[0,[],0,\"Zapier is a no-code tool that allows you to build powerful automations, and our official integration allows you to connect your Ghost site to more than 1,000 external services.\"]]],[1,\"blockquote\",[[0,[1],1,\"Example\"],[0,[],0,\": When someone new subscribes to a newsletter on a Ghost site (Trigger) then the contact information is automatically pushed into MailChimp (Action).\"]]],[1,\"p\",[[0,[1],1,\"Here\'s a few of the most popular automation templates:\"],[0,[],0,\" \"]]],[10,1],[1,\"h2\",[[0,[],0,\"Custom integrations\"]]],[1,\"p\",[[0,[],0,\"For more advanced automation, it\'s possible to create custom Ghost integrations with dedicated API keys from the Integrations page within Ghost Admin. \"]]],[10,2],[1,\"p\",[[0,[],0,\"These custom integrations allow you to use the Ghost API without needing to write code, and create powerful workflows such as sending content from your favorite desktop editor into Ghost as a new draft.\"]]]],\"ghostVersion\":\"4.0\"}','<p>It\'s possible to extend your Ghost site and connect it with hundreds of the most popular apps and tools using integrations. </p><p>Whether you need to automatically publish new posts on social media, connect your favorite analytics tool, sync your community or embed forms into your content — our <a href=\"https://ghost.org/integrations/\">integrations library</a> has got it all covered with hundreds of integration tutorials.</p><p>Many integrations are as simple as inserting an embed by pasting a link, or copying a snippet of code directly from an app and pasting it into Ghost. Our integration tutorials are used by creators of all kinds to get apps and integrations up and running in no time — no technical knowledge required.</p><figure class=\"kg-card kg-image-card kg-width-full\"><img src=\"https://static.ghost.org/v4.0.0/images/integrations-icons.png\" class=\"kg-image\" alt loading=\"lazy\"></figure><h2 id=\"zapier\">Zapier</h2><p>Zapier is a no-code tool that allows you to build powerful automations, and our official integration allows you to connect your Ghost site to more than 1,000 external services.</p><blockquote><strong>Example</strong>: When someone new subscribes to a newsletter on a Ghost site (Trigger) then the contact information is automatically pushed into MailChimp (Action).</blockquote><p><strong>Here\'s a few of the most popular automation templates:</strong> </p><!--kg-card-begin: markdown--><script src=\"https://zapier.com/apps/embed/widget.js?services=Ghost,-shortcm,-hubspot,-sendpulse,-noticeable,-aweber,-icontact,-facebook-pages,-github,-medium,-slack,-mailchimp,-activecampaign,-twitter,-discourse&container,-convertkit,-drip,-airtable=true&limit=5\"></script>\n<!--kg-card-end: markdown--><h2 id=\"custom-integrations\">Custom integrations</h2><p>For more advanced automation, it\'s possible to create custom Ghost integrations with dedicated API keys from the Integrations page within Ghost Admin. </p><figure class=\"kg-card kg-image-card\"><img src=\"https://static.ghost.org/v4.0.0/images/iawriter-integration.png\" class=\"kg-image\" alt loading=\"lazy\" width=\"2244\" height=\"936\"></figure><p>These custom integrations allow you to use the Ghost API without needing to write code, and create powerful workflows such as sending content from your favorite desktop editor into Ghost as a new draft.</p>','6091ec1c517db00001e536e1','It\'s possible to extend your Ghost site and connect it with hundreds of the most\npopular apps and tools using integrations. \n\nWhether you need to automatically publish new posts on social media, connect\nyour favorite analytics tool, sync your community or embed forms into your\ncontent — our integrations library [https://ghost.org/integrations/] has got it\nall covered with hundreds of integration tutorials.\n\nMany integrations are as simple as inserting an embed by pasting a link, or\ncopying a snippet of code directly from an app and pasting it into Ghost. Our\nintegration tutorials are used by creators of all kinds to get apps and\nintegrations up and running in no time — no technical knowledge required.\n\nZapier\nZapier is a no-code tool that allows you to build powerful automations, and our\nofficial integration allows you to connect your Ghost site to more than 1,000\nexternal services.\n\n> Example: When someone new subscribes to a newsletter on a Ghost site (Trigger)\nthen the contact information is automatically pushed into MailChimp (Action).\nHere\'s a few of the most popular automation templates: \n\nCustom integrations\nFor more advanced automation, it\'s possible to create custom Ghost integrations\nwith dedicated API keys from the Integrations page within Ghost Admin. \n\nThese custom integrations allow you to use the Ghost API without needing to\nwrite code, and create powerful workflows such as sending content from your\nfavorite desktop editor into Ghost as a new draft.','https://static.ghost.org/v4.0.0/images/app-integrations.png',0,'post','published',NULL,'public','none','5951f5fca366002ebd5dbef7','2021-05-05 00:51:40','1','2021-05-05 00:51:40','1','2021-05-05 00:51:40','1','Work with all your favorite apps and tools or create your own custom integrations using the Ghost API.',NULL,NULL,NULL,NULL),('6091ec1c517db00001e536e3','44d95c6f-a7a6-4788-b372-fc4ba051e140','How to grow your business around an audience','grow','{\"version\":\"0.3.1\",\"atoms\":[[\"soft-return\",\"\",{}],[\"soft-return\",\"\",{}],[\"soft-return\",\"\",{}],[\"soft-return\",\"\",{}],[\"soft-return\",\"\",{}],[\"soft-return\",\"\",{}],[\"soft-return\",\"\",{}],[\"soft-return\",\"\",{}],[\"soft-return\",\"\",{}],[\"soft-return\",\"\",{}],[\"soft-return\",\"\",{}],[\"soft-return\",\"\",{}]],\"cards\":[[\"hr\",{}]],\"markups\":[[\"strong\"],[\"a\",[\"href\",\"https://ghost.org/pricing/\"]],[\"em\"],[\"a\",[\"href\",\"https://ghost.org/blog/how-to-create-a-newsletter/\"]],[\"a\",[\"href\",\"https://ghost.org/blog/membership-sites/\"]],[\"a\",[\"href\",\"https://newsletterguide.org/\"]],[\"a\",[\"href\",\"https://ghost.org/blog/find-your-niche-creator-economy/\"]],[\"a\",[\"href\",\"https://ghost.org/blog/newsletter-referral-programs/\"]]],\"sections\":[[1,\"p\",[[0,[],0,\"As you grow, you\'ll probably want to start inviting team members and collaborators to your site. Ghost has a number of different user roles for your team:\"]]],[1,\"p\",[[0,[0],1,\"Contributors\"],[1,[],0,0],[0,[],0,\"This is the base user level in Ghost. Contributors can create and edit their own draft posts, but they are unable to edit drafts of others or publish posts. Contributors are \"],[0,[0],1,\"untrusted\"],[0,[],0,\" users with the most basic access to your publication.\"]]],[1,\"p\",[[0,[0],1,\"Authors\"],[1,[],0,1],[0,[],0,\"Authors are the 2nd user level in Ghost. Authors can write, edit and publish their own posts. Authors are \"],[0,[0],1,\"trusted\"],[0,[],0,\" users. If you don\'t trust users to be allowed to publish their own posts, they should be set as Contributors.\"]]],[1,\"p\",[[0,[0],1,\"Editors\"],[1,[],0,2],[0,[],0,\"Editors are the 3rd user level in Ghost. Editors can do everything that an Author can do, but they can also edit and publish the posts of others - as well as their own. Editors can also invite new Contributors & Authors to the site.\"]]],[1,\"p\",[[0,[0],1,\"Administrators\"],[1,[],0,3],[0,[],0,\"The top user level in Ghost is Administrator. Again, administrators can do everything that Authors and Editors can do, but they can also edit all site settings and data, not just content. Additionally, administrators have full access to invite, manage or remove any other user of the site.\"],[1,[],0,4],[1,[],0,5],[0,[0],1,\"The Owner\"],[1,[],0,6],[0,[],0,\"There is only ever one owner of a Ghost site. The owner is a special user which has all the same permissions as an Administrator, but with two exceptions: The Owner can never be deleted. And in some circumstances the owner will have access to additional special settings if applicable. For example: billing details, if using \"],[0,[1,0],2,\"Ghost(Pro)\"],[0,[],0,\".\"]]],[1,\"blockquote\",[[0,[2],1,\"Ask all of your users to fill out their user profiles, including bio and social links. These will populate rich structured data for posts and generally create more opportunities for themes to fully populate their design.\"]]],[10,0],[1,\"p\",[[0,[],0,\"If you\'re looking for insights, tips and reference materials to expand your content business, here\'s 5 top resources to get you started:\"]]],[3,\"ul\",[[[0,[3,0],2,\"How to create a premium newsletter (+ some case studies)\"],[0,[0],1,\" \"],[0,[],0,\" \"],[1,[],0,7],[0,[],0,\"Learn how others run successful paid email newsletter products\"]],[[0,[0,4],2,\"The ultimate guide to membership websites for creators\"],[1,[],0,8],[0,[],0,\"Tips to help you build, launch and grow your new membership business\"]],[[0,[0,5],2,\"The Newsletter Guide\"],[1,[],0,9],[0,[],0,\"A 201 guide for taking your newsletters to the next level\"]],[[0,[6,0],2,\"The proven way to find your niche, explained\"],[1,[],0,10],[0,[],0,\"Find the overlap and find a monetizable niche that gets noticed\"]],[[0,[0,7],2,\"Should you launch a referral program? \"],[1,[],0,11],[0,[],0,\"Strategies for building a sustainable referral growth machine\"]]]]],\"ghostVersion\":\"4.0\"}','<p>As you grow, you\'ll probably want to start inviting team members and collaborators to your site. Ghost has a number of different user roles for your team:</p><p><strong>Contributors</strong><br>This is the base user level in Ghost. Contributors can create and edit their own draft posts, but they are unable to edit drafts of others or publish posts. Contributors are <strong>untrusted</strong> users with the most basic access to your publication.</p><p><strong>Authors</strong><br>Authors are the 2nd user level in Ghost. Authors can write, edit and publish their own posts. Authors are <strong>trusted</strong> users. If you don\'t trust users to be allowed to publish their own posts, they should be set as Contributors.</p><p><strong>Editors</strong><br>Editors are the 3rd user level in Ghost. Editors can do everything that an Author can do, but they can also edit and publish the posts of others - as well as their own. Editors can also invite new Contributors &amp; Authors to the site.</p><p><strong>Administrators</strong><br>The top user level in Ghost is Administrator. Again, administrators can do everything that Authors and Editors can do, but they can also edit all site settings and data, not just content. Additionally, administrators have full access to invite, manage or remove any other user of the site.<br><br><strong>The Owner</strong><br>There is only ever one owner of a Ghost site. The owner is a special user which has all the same permissions as an Administrator, but with two exceptions: The Owner can never be deleted. And in some circumstances the owner will have access to additional special settings if applicable. For example: billing details, if using <a href=\"https://ghost.org/pricing/\"><strong>Ghost(Pro)</strong></a>.</p><blockquote><em>Ask all of your users to fill out their user profiles, including bio and social links. These will populate rich structured data for posts and generally create more opportunities for themes to fully populate their design.</em></blockquote><hr><p>If you\'re looking for insights, tips and reference materials to expand your content business, here\'s 5 top resources to get you started:</p><ul><li><a href=\"https://ghost.org/blog/how-to-create-a-newsletter/\"><strong>How to create a premium newsletter (+ some case studies)</strong></a><strong> </strong> <br>Learn how others run successful paid email newsletter products</li><li><strong><a href=\"https://ghost.org/blog/membership-sites/\">The ultimate guide to membership websites for creators</a></strong><br>Tips to help you build, launch and grow your new membership business</li><li><strong><a href=\"https://newsletterguide.org/\">The Newsletter Guide</a></strong><br>A 201 guide for taking your newsletters to the next level</li><li><a href=\"https://ghost.org/blog/find-your-niche-creator-economy/\"><strong>The proven way to find your niche, explained</strong></a><br>Find the overlap and find a monetizable niche that gets noticed</li><li><strong><a href=\"https://ghost.org/blog/newsletter-referral-programs/\">Should you launch a referral program? </a></strong><br>Strategies for building a sustainable referral growth machine</li></ul>','6091ec1c517db00001e536e3','As you grow, you\'ll probably want to start inviting team members and\ncollaborators to your site. Ghost has a number of different user roles for your\nteam:\n\nContributors\nThis is the base user level in Ghost. Contributors can create and edit their own\ndraft posts, but they are unable to edit drafts of others or publish posts.\nContributors are untrusted users with the most basic access to your publication.\n\nAuthors\nAuthors are the 2nd user level in Ghost. Authors can write, edit and publish\ntheir own posts. Authors are trusted users. If you don\'t trust users to be\nallowed to publish their own posts, they should be set as Contributors.\n\nEditors\nEditors are the 3rd user level in Ghost. Editors can do everything that an\nAuthor can do, but they can also edit and publish the posts of others - as well\nas their own. Editors can also invite new Contributors & Authors to the site.\n\nAdministrators\nThe top user level in Ghost is Administrator. Again, administrators can do\neverything that Authors and Editors can do, but they can also edit all site\nsettings and data, not just content. Additionally, administrators have full\naccess to invite, manage or remove any other user of the site.\n\nThe Owner\nThere is only ever one owner of a Ghost site. The owner is a special user which\nhas all the same permissions as an Administrator, but with two exceptions: The\nOwner can never be deleted. And in some circumstances the owner will have access\nto additional special settings if applicable. For example: billing details, if\nusing Ghost(Pro) [https://ghost.org/pricing/].\n\n> Ask all of your users to fill out their user profiles, including bio and social\nlinks. These will populate rich structured data for posts and generally create\nmore opportunities for themes to fully populate their design.\n\n--------------------------------------------------------------------------------\n\nIf you\'re looking for insights, tips and reference materials to expand your\ncontent business, here\'s 5 top resources to get you started:\n\n * How to create a premium newsletter (+ some case studies)\n   [https://ghost.org/blog/how-to-create-a-newsletter/] \n   Learn how others run successful paid email newsletter products\n * The ultimate guide to membership websites for creators\n   [https://ghost.org/blog/membership-sites/]\n   Tips to help you build, launch and grow your new membership business\n * The Newsletter Guide [https://newsletterguide.org/]\n   A 201 guide for taking your newsletters to the next level\n * The proven way to find your niche, explained\n   [https://ghost.org/blog/find-your-niche-creator-economy/]\n   Find the overlap and find a monetizable niche that gets noticed\n * Should you launch a referral program?\n   [https://ghost.org/blog/newsletter-referral-programs/]\n   Strategies for building a sustainable referral growth machine','https://static.ghost.org/v4.0.0/images/admin-settings.png',0,'post','published',NULL,'public','none','5951f5fca366002ebd5dbef7','2021-05-05 00:51:40','1','2021-05-05 00:51:40','1','2021-05-05 00:51:41','1','A guide to collaborating with other staff users to publish, and some resources to help you with the next steps of growing your business',NULL,NULL,NULL,NULL),('6091ec1c517db00001e536e5','55d6ac12-9c16-43fd-908e-5a4c29d50f7e','Selling premium memberships with recurring revenue','sell','{\"version\":\"0.3.1\",\"atoms\":[],\"cards\":[[\"image\",{\"src\":\"https://static.ghost.org/v4.0.0/images/thebrowser.jpg\",\"width\":1600,\"height\":2000,\"href\":\"https://thebrowser.com\",\"caption\":\"The Browser has over 10,000 paying subscribers\"}],[\"paywall\",{}]],\"markups\":[[\"a\",[\"href\",\"https://stripe.com\"]],[\"strong\"],[\"a\",[\"href\",\"https://stratechery.com\"]],[\"a\",[\"href\",\"https://www.theinformation.com\"]],[\"a\",[\"href\",\"https://thebrowser.com\"]]],\"sections\":[[1,\"p\",[[0,[],0,\"For creators and aspiring entrepreneurs looking to generate a sustainable recurring revenue stream from their creative work, Ghost has built-in payments allowing you to create a subscription commerce business.\"]]],[1,\"p\",[[0,[],0,\"Connect your \"],[0,[0],1,\"Stripe\"],[0,[],0,\" account to Ghost, and you\'ll be able to quickly and easily create monthly and yearly premium plans for members to subscribe to, as well as complimentary plans for friends and family.\"]]],[1,\"p\",[[0,[],0,\"Ghost takes \"],[0,[1],1,\"0% payment fees\"],[0,[],0,\", so everything you make is yours to keep!\"]]],[1,\"p\",[[0,[],0,\"Using subscriptions, you can build an independent media business like \"],[0,[2],1,\"Stratechery\"],[0,[],0,\", \"],[0,[3],1,\"The Information\"],[0,[],0,\", or \"],[0,[4],1,\"The Browser\"],[0,[],0,\".\"]]],[1,\"p\",[[0,[],0,\"The creator economy is just getting started, and Ghost allows you to build something based on technology that you own and control.\"]]],[10,0],[1,\"p\",[[0,[],0,\"Most successful subscription businesses publish a mix of free and paid posts to attract a new audience, and upsell the most loyal members to a premium offering. You can also mix different access levels within the same post, showing a free preview to logged out members and then, right when you\'re ready for a cliffhanger, that\'s a good time to...\"]]],[10,1],[1,\"p\",[[0,[],0,\"Hold back some of the best bits for paying members only! \"]]],[1,\"p\",[[0,[],0,\"The \"],[0,[1],1,\"Public preview\"],[0,[],0,\" card allows to create a divide between how much of your post should be available as a public free-preview, and how much should be restricted based on the post access level.\"]]],[1,\"p\",[[0,[],0,\"These last paragraphs are only visible on the site if you\'re logged in as a paying member. To test this out, you can connect a Stripe account, create a member account for yourself, and give yourself a complimentary premium plan.\"]]]],\"ghostVersion\":\"4.0\"}','<p>For creators and aspiring entrepreneurs looking to generate a sustainable recurring revenue stream from their creative work, Ghost has built-in payments allowing you to create a subscription commerce business.</p><p>Connect your <a href=\"https://stripe.com\">Stripe</a> account to Ghost, and you\'ll be able to quickly and easily create monthly and yearly premium plans for members to subscribe to, as well as complimentary plans for friends and family.</p><p>Ghost takes <strong>0% payment fees</strong>, so everything you make is yours to keep!</p><p>Using subscriptions, you can build an independent media business like <a href=\"https://stratechery.com\">Stratechery</a>, <a href=\"https://www.theinformation.com\">The Information</a>, or <a href=\"https://thebrowser.com\">The Browser</a>.</p><p>The creator economy is just getting started, and Ghost allows you to build something based on technology that you own and control.</p><figure class=\"kg-card kg-image-card kg-card-hascaption\"><a href=\"https://thebrowser.com\"><img src=\"https://static.ghost.org/v4.0.0/images/thebrowser.jpg\" class=\"kg-image\" alt loading=\"lazy\" width=\"1600\" height=\"2000\"></a><figcaption>The Browser has over 10,000 paying subscribers</figcaption></figure><p>Most successful subscription businesses publish a mix of free and paid posts to attract a new audience, and upsell the most loyal members to a premium offering. You can also mix different access levels within the same post, showing a free preview to logged out members and then, right when you\'re ready for a cliffhanger, that\'s a good time to...</p><!--members-only--><p>Hold back some of the best bits for paying members only! </p><p>The <strong>Public preview</strong> card allows to create a divide between how much of your post should be available as a public free-preview, and how much should be restricted based on the post access level.</p><p>These last paragraphs are only visible on the site if you\'re logged in as a paying member. To test this out, you can connect a Stripe account, create a member account for yourself, and give yourself a complimentary premium plan.</p>','6091ec1c517db00001e536e5','For creators and aspiring entrepreneurs looking to generate a sustainable\nrecurring revenue stream from their creative work, Ghost has built-in payments\nallowing you to create a subscription commerce business.\n\nConnect your Stripe [https://stripe.com] account to Ghost, and you\'ll be able to\nquickly and easily create monthly and yearly premium plans for members to\nsubscribe to, as well as complimentary plans for friends and family.\n\nGhost takes 0% payment fees, so everything you make is yours to keep!\n\nUsing subscriptions, you can build an independent media business like \nStratechery [https://stratechery.com], The Information\n[https://www.theinformation.com], or The Browser [https://thebrowser.com].\n\nThe creator economy is just getting started, and Ghost allows you to build\nsomething based on technology that you own and control.\n\n[https://thebrowser.com]The Browser has over 10,000 paying subscribersMost\nsuccessful subscription businesses publish a mix of free and paid posts to\nattract a new audience, and upsell the most loyal members to a premium offering.\nYou can also mix different access levels within the same post, showing a free\npreview to logged out members and then, right when you\'re ready for a\ncliffhanger, that\'s a good time to...\n\nHold back some of the best bits for paying members only! \n\nThe Public preview card allows to create a divide between how much of your post\nshould be available as a public free-preview, and how much should be restricted\nbased on the post access level.\n\nThese last paragraphs are only visible on the site if you\'re logged in as a\npaying member. To test this out, you can connect a Stripe account, create a\nmember account for yourself, and give yourself a complimentary premium plan.','https://static.ghost.org/v4.0.0/images/organizing-your-content.png',0,'post','published',NULL,'paid','none','5951f5fca366002ebd5dbef7','2021-05-05 00:51:40','1','2021-05-05 00:51:40','1','2021-05-05 00:51:42','1',NULL,NULL,NULL,NULL,NULL),('6091ec1c517db00001e536e7','8b226f85-0d0f-4dc3-ac7f-6ddf35737daa','Building your audience with subscriber signups','portal','{\"version\":\"0.3.1\",\"atoms\":[],\"cards\":[[\"image\",{\"src\":\"https://static.ghost.org/v4.0.0/images/portalsettings.png\",\"width\":2924,\"height\":1810,\"cardWidth\":\"wide\"}],[\"hr\",{}]],\"markups\":[[\"em\"],[\"a\",[\"href\",\"#/portal\"]],[\"a\",[\"href\",\"__GHOST_URL__/sell/\"]]],\"sections\":[[1,\"p\",[[0,[],0,\"What sets Ghost apart from other products is that you can publish content and grow your audience using the same platform. Rather than just endlessly posting and hoping someone is listening, you can track real signups against your work and have them subscribe to be notified of future posts. The feature that makes all this possible is called \"],[0,[0],1,\"Portal\"],[0,[],0,\".\"]]],[1,\"p\",[[0,[],0,\"Portal is an embedded interface for your audience to sign up to your site. It works on every Ghost site, with every theme, and for any type of publisher. \"]]],[1,\"p\",[[0,[],0,\"You can customize the design, content and settings of Portal to suit your site, whether you just want people to sign up to your newsletter — or you\'re running a full premium publication with user sign-ins and private content.\"]]],[10,0],[1,\"p\",[[0,[],0,\"Once people sign up to your site, they\'ll receive an email confirmation with a link to click. The link acts as an automatic sign-in, so subscribers will be automatically signed-in to your site when they click on it. There are a couple of interesting angles to this:\"]]],[1,\"p\",[[0,[],0,\"Because subscribers are automatically able to sign in and out of your site as registered members: You can (optionally) restrict access to posts and pages depending on whether people are signed-in or not. So if you want to publish some posts for free, but keep some really great stuff for members-only, this can be a great draw to encourage people to sign up!\"]]],[1,\"p\",[[0,[],0,\"Ghost members sign in using email authentication links, so there are no passwords for people to set or forget. You can turn any list of email subscribers into a database of registered members who can sign in to your site. Like magic.\"]]],[1,\"p\",[[0,[],0,\"Portal makes all of this possible, and it appears by default as a floating button in the bottom-right corner of your site. When people are logged out, clicking it will open a sign-up/sign-in window. When members are logged in, clicking the Portal button will open the account menu where they can edit their name, email, and subscription settings.\"]]],[1,\"p\",[[0,[],0,\"The floating Portal button is completely optional. If you prefer, you can add manual links to your content, navigation, or theme to trigger it instead.\"]]],[1,\"p\",[[0,[],0,\"Like this! \"],[0,[1],1,\"Sign up here\"]]],[10,1],[1,\"p\",[[0,[],0,\"As you start to grow your registered audience, you\'ll be able to get a sense of who you\'re publishing \"],[0,[0],1,\"for\"],[0,[],0,\" and where those people are coming \"],[0,[0],1,\"from\"],[0,[],0,\". Best of all: You\'ll have a straightforward, reliable way to connect with people who enjoy your work.\"]]],[1,\"p\",[[0,[],0,\"Social networks go in and out of fashion all the time. Email addresses are timeless.\"]]],[1,\"p\",[[0,[],0,\"Growing your audience is valuable no matter what type of site you run, but if your content \"],[0,[0],1,\"is\"],[0,[],0,\" your business, then you might also be interested in \"],[0,[2],1,\"setting up premium subscriptions\"],[0,[],0,\".\"]]]],\"ghostVersion\":\"4.0\"}','<p>What sets Ghost apart from other products is that you can publish content and grow your audience using the same platform. Rather than just endlessly posting and hoping someone is listening, you can track real signups against your work and have them subscribe to be notified of future posts. The feature that makes all this possible is called <em>Portal</em>.</p><p>Portal is an embedded interface for your audience to sign up to your site. It works on every Ghost site, with every theme, and for any type of publisher. </p><p>You can customize the design, content and settings of Portal to suit your site, whether you just want people to sign up to your newsletter — or you\'re running a full premium publication with user sign-ins and private content.</p><figure class=\"kg-card kg-image-card kg-width-wide\"><img src=\"https://static.ghost.org/v4.0.0/images/portalsettings.png\" class=\"kg-image\" alt loading=\"lazy\" width=\"2924\" height=\"1810\"></figure><p>Once people sign up to your site, they\'ll receive an email confirmation with a link to click. The link acts as an automatic sign-in, so subscribers will be automatically signed-in to your site when they click on it. There are a couple of interesting angles to this:</p><p>Because subscribers are automatically able to sign in and out of your site as registered members: You can (optionally) restrict access to posts and pages depending on whether people are signed-in or not. So if you want to publish some posts for free, but keep some really great stuff for members-only, this can be a great draw to encourage people to sign up!</p><p>Ghost members sign in using email authentication links, so there are no passwords for people to set or forget. You can turn any list of email subscribers into a database of registered members who can sign in to your site. Like magic.</p><p>Portal makes all of this possible, and it appears by default as a floating button in the bottom-right corner of your site. When people are logged out, clicking it will open a sign-up/sign-in window. When members are logged in, clicking the Portal button will open the account menu where they can edit their name, email, and subscription settings.</p><p>The floating Portal button is completely optional. If you prefer, you can add manual links to your content, navigation, or theme to trigger it instead.</p><p>Like this! <a href=\"#/portal\">Sign up here</a></p><hr><p>As you start to grow your registered audience, you\'ll be able to get a sense of who you\'re publishing <em>for</em> and where those people are coming <em>from</em>. Best of all: You\'ll have a straightforward, reliable way to connect with people who enjoy your work.</p><p>Social networks go in and out of fashion all the time. Email addresses are timeless.</p><p>Growing your audience is valuable no matter what type of site you run, but if your content <em>is</em> your business, then you might also be interested in <a href=\"__GHOST_URL__/sell/\">setting up premium subscriptions</a>.</p>','6091ec1c517db00001e536e7','What sets Ghost apart from other products is that you can publish content and\ngrow your audience using the same platform. Rather than just endlessly posting\nand hoping someone is listening, you can track real signups against your work\nand have them subscribe to be notified of future posts. The feature that makes\nall this possible is called Portal.\n\nPortal is an embedded interface for your audience to sign up to your site. It\nworks on every Ghost site, with every theme, and for any type of publisher. \n\nYou can customize the design, content and settings of Portal to suit your site,\nwhether you just want people to sign up to your newsletter — or you\'re running a\nfull premium publication with user sign-ins and private content.\n\nOnce people sign up to your site, they\'ll receive an email confirmation with a\nlink to click. The link acts as an automatic sign-in, so subscribers will be\nautomatically signed-in to your site when they click on it. There are a couple\nof interesting angles to this:\n\nBecause subscribers are automatically able to sign in and out of your site as\nregistered members: You can (optionally) restrict access to posts and pages\ndepending on whether people are signed-in or not. So if you want to publish some\nposts for free, but keep some really great stuff for members-only, this can be a\ngreat draw to encourage people to sign up!\n\nGhost members sign in using email authentication links, so there are no\npasswords for people to set or forget. You can turn any list of email\nsubscribers into a database of registered members who can sign in to your site.\nLike magic.\n\nPortal makes all of this possible, and it appears by default as a floating\nbutton in the bottom-right corner of your site. When people are logged out,\nclicking it will open a sign-up/sign-in window. When members are logged in,\nclicking the Portal button will open the account menu where they can edit their\nname, email, and subscription settings.\n\nThe floating Portal button is completely optional. If you prefer, you can add\nmanual links to your content, navigation, or theme to trigger it instead.\n\nLike this! Sign up here\n\n\n--------------------------------------------------------------------------------\n\nAs you start to grow your registered audience, you\'ll be able to get a sense of\nwho you\'re publishing for and where those people are coming from. Best of all:\nYou\'ll have a straightforward, reliable way to connect with people who enjoy\nyour work.\n\nSocial networks go in and out of fashion all the time. Email addresses are\ntimeless.\n\nGrowing your audience is valuable no matter what type of site you run, but if\nyour content is your business, then you might also be interested in setting up\npremium subscriptions [__GHOST_URL__/sell/].','https://static.ghost.org/v4.0.0/images/creating-a-custom-theme.png',0,'post','published',NULL,'public','none','5951f5fca366002ebd5dbef7','2021-05-05 00:51:40','1','2021-05-05 00:51:40','1','2021-05-05 00:51:43','1','How Ghost allows you to turn anonymous readers into an audience of active subscribers, so you know what\'s working and what isn\'t.',NULL,NULL,NULL,NULL),('6091ec1c517db00001e536e9','230acb9d-52a0-4de5-8550-5d557e0b7714','Writing and managing content in Ghost, an advanced guide','write','{\"version\":\"0.3.1\",\"atoms\":[],\"cards\":[[\"image\",{\"src\":\"https://static.ghost.org/v4.0.0/images/editor.png\",\"width\":3182,\"height\":1500,\"cardWidth\":\"wide\",\"caption\":\"The Ghost editor. Also available in dark-mode, for late night writing sessions.\"}],[\"bookmark\",{\"type\":\"bookmark\",\"url\":\"https://opensubscriptionplatforms.com/\",\"metadata\":{\"url\":\"https://opensubscriptionplatforms.com\",\"title\":\"Open Subscription Platforms\",\"description\":\"A shared movement for independent subscription data.\",\"author\":null,\"publisher\":\"Open Subscription Platforms\",\"thumbnail\":\"https://opensubscriptionplatforms.com/images/osp-card.png\",\"icon\":\"https://opensubscriptionplatforms.com/images/favicon.png\"}}],[\"embed\",{\"url\":\"https://www.youtube.com/watch?v=hmH3XMlms8E\",\"html\":\"<iframe width=\\\"200\\\" height=\\\"113\\\" src=\\\"https://www.youtube.com/embed/hmH3XMlms8E?feature=oembed\\\" frameborder=\\\"0\\\" allow=\\\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\\\" allowfullscreen></iframe>\",\"type\":\"video\",\"metadata\":{\"title\":\"\\\"VELA\\\" Episode 1 of 4 | John John Florence\",\"author_name\":\"John John Florence\",\"author_url\":\"https://www.youtube.com/c/JJF\",\"height\":113,\"width\":200,\"version\":\"1.0\",\"provider_name\":\"YouTube\",\"provider_url\":\"https://www.youtube.com/\",\"thumbnail_height\":360,\"thumbnail_width\":480,\"thumbnail_url\":\"https://i.ytimg.com/vi/hmH3XMlms8E/hqdefault.jpg\"}}],[\"image\",{\"src\":\"https://static.ghost.org/v4.0.0/images/andreas-selter-xSMqGH7gi6o-unsplash.jpg\",\"width\":6000,\"height\":4000,\"cardWidth\":\"full\",\"caption\":\"\"}],[\"gallery\",{\"images\":[{\"fileName\":\"andreas-selter-e4yK8QQlZa0-unsplash.jpg\",\"row\":0,\"width\":4572,\"height\":3048,\"src\":\"https://static.ghost.org/v4.0.0/images/andreas-selter-e4yK8QQlZa0-unsplash.jpg\"},{\"fileName\":\"steve-carter-Ixp4YhCKZkI-unsplash.jpg\",\"row\":0,\"width\":4032,\"height\":2268,\"src\":\"https://static.ghost.org/v4.0.0/images/steve-carter-Ixp4YhCKZkI-unsplash.jpg\"}],\"caption\":\"\"}],[\"image\",{\"src\":\"https://static.ghost.org/v4.0.0/images/lukasz-szmigiel-jFCViYFYcus-unsplash.jpg\",\"width\":2560,\"height\":1705,\"cardWidth\":\"wide\"}],[\"gallery\",{\"images\":[{\"fileName\":\"jd-mason-hPiEFq6-Eto-unsplash.jpg\",\"row\":0,\"width\":5184,\"height\":3888,\"src\":\"https://static.ghost.org/v4.0.0/images/jd-mason-hPiEFq6-Eto-unsplash.jpg\"},{\"fileName\":\"jp-valery-OBpOP9GVH9U-unsplash.jpg\",\"row\":0,\"width\":5472,\"height\":3648,\"src\":\"https://static.ghost.org/v4.0.0/images/jp-valery-OBpOP9GVH9U-unsplash.jpg\"}],\"caption\":\"Peaceful places\"}],[\"image\",{\"src\":\"https://static.ghost.org/v4.0.0/images/createsnippet.png\",\"width\":2282,\"height\":1272,\"cardWidth\":\"wide\"}],[\"hr\",{}],[\"image\",{\"src\":\"https://static.ghost.org/v4.0.0/images/preview.png\",\"width\":3166,\"height\":2224,\"cardWidth\":\"wide\"}],[\"hr\",{}]],\"markups\":[[\"em\"],[\"code\"]],\"sections\":[[1,\"p\",[[0,[],0,\"Ghost comes with a best-in-class editor which does its very best to get out of the way, and let you focus on your content. Don\'t let its minimal looks fool you, though, beneath the surface lies a powerful editing toolset designed to accommodate the extensive needs of modern creators.\"]]],[1,\"p\",[[0,[],0,\"For many, the base canvas of the Ghost editor will feel familiar. You can start writing as you would expect, highlight content to access the toolbar you would expect, and generally use all of the keyboard shortcuts you would expect.\"]]],[1,\"p\",[[0,[],0,\"Our main focus in building the Ghost editor is to try and make as many things that you hope/expect might work: actually work. \"]]],[3,\"ul\",[[[0,[],0,\"You can copy and paste raw content from web pages, and Ghost will do its best to correctly preserve the formatting. \"]],[[0,[],0,\"Pasting an image from your clipboard will upload inline.\"]],[[0,[],0,\"Pasting a social media URL will automatically create an embed.\"]],[[0,[],0,\"Highlight a word in the editor and paste a URL from your clipboard on top: Ghost will turn it into a link.\"]],[[0,[],0,\"You can also paste (or write!) Markdown and Ghost will usually be able to auto-convert it into fully editable, formatted content.\"]]]],[10,0],[1,\"p\",[[0,[],0,\"The goal, as much as possible, is for things to work so that you don\'t have to \"],[0,[0],1,\"think\"],[0,[],0,\" so much about the editor. You won\'t find any disastrous \\\"block builders\\\" here, where you have to open 6 submenus and choose from 18 different but identical alignment options. That\'s not what Ghost is about.\"]]],[1,\"p\",[[0,[],0,\"What you will find though, is dynamic cards which allow you to embed rich media into your posts and create beautifully laid out stories.\"]]],[1,\"h2\",[[0,[],0,\"Using cards\"]]],[1,\"p\",[[0,[],0,\"You can insert dynamic cards inside post content using the \"],[0,[1],1,\"+\"],[0,[],0,\" button, which appears on new lines, or by typing \"],[0,[1],1,\"/\"],[0,[],0,\" on a new line to trigger the card menu. Many of the choices are simple and intuitive, like bookmark cards, which allow you to create rich links with embedded structured data:\"]]],[10,1],[1,\"p\",[[0,[],0,\"or embed cards which make it easy to insert content you want to share with your audience, from external services:\"]]],[10,2],[1,\"p\",[[0,[],0,\"But, dig a little deeper, and you\'ll also find more advanced cards, like one that only shows up in email newsletters (great for personalized introductions) and a comprehensive set of specialized cards for different types of images and galleries.\"]]],[1,\"blockquote\",[[0,[],0,\"Once you  start mixing text and image cards creatively, the whole narrative of the story changes. Suddenly, you\'re working in a new format.\"]]],[10,3],[1,\"p\",[[0,[],0,\"As it turns out, sometimes pictures and a thousand words go together really well. Telling people a great story often has much more impact if they can feel, even for a moment, as though they were right there with you.\"]]],[10,4],[10,5],[10,6],[1,\"p\",[[0,[],0,\"Galleries and image cards can be combined in so many different ways — the only limit is your imagination.\"]]],[1,\"h2\",[[0,[],0,\"Build workflows with snippets\"]]],[1,\"p\",[[0,[],0,\"One of the most powerful features of the Ghost editor is the ability to create and re-use content snippets. If you\'ve ever used an email client with a concept of \"],[0,[0],1,\"saved replies\"],[0,[],0,\" then this will be immediately intuitive.\"]]],[1,\"p\",[[0,[],0,\"To create a snippet, select a piece of content in the editor that you\'d like to re-use in future, then click on the snippet icon in the toolbar. Give your snippet a name, and you\'re all done. Now your snippet will be available from within the card menu, or you can search for it directly using the \"],[0,[1],1,\"/\"],[0,[],0,\" command.\"]]],[1,\"p\",[[0,[],0,\"This works really well for saving images you might want to use often, like a company logo or team photo, links to resources you find yourself often linking to, or introductions and passages that you want to remember.\"]]],[10,7],[1,\"p\",[[0,[],0,\"You can even build entire post templates or outlines to create a quick, re-usable workflow for publishing over time. Or build custom design elements for your post with an HTML card, and use a snippet to insert it.\"]]],[1,\"p\",[[0,[],0,\"Once you get a few useful snippets set up, it\'s difficult to go back to the old way of diving through media libraries and trawling for that one thing you know you used somewhere that one time.\"]]],[10,8],[1,\"h2\",[[0,[],0,\"Publishing and newsletters the easy way\"]]],[1,\"p\",[[0,[],0,\"When you\'re ready to publish, Ghost makes it as simple as possible to deliver your new post to all your existing members. Just hit the \"],[0,[0],1,\"Preview\"],[0,[],0,\" link and you\'ll get a chance to see what your content looks like on Web, Mobile, Email and Social.\"]]],[10,9],[1,\"p\",[[0,[],0,\"You can send yourself a test newsletter to make sure everything looks good in your email client, and then hit the \"],[0,[0],1,\"Publish\"],[0,[],0,\" button to decide who to deliver it to.\"]]],[1,\"p\",[[0,[],0,\"Ghost comes with a streamlined, optimized email newsletter template that has settings built-in for you to customize the colors and typography. We\'ve spent countless hours refining the template to make sure it works great across all email clients, and performs well for email deliverability.\"]]],[1,\"p\",[[0,[],0,\"So, you don\'t need to fight the awful process of building a custom email template from scratch. It\'s all done already!\"]]],[10,10],[1,\"p\",[[0,[],0,\"The Ghost editor is powerful enough to do whatever you want it to do. With a little exploration, you\'ll be up and running in no time.\"]]]],\"ghostVersion\":\"4.0\"}','<p>Ghost comes with a best-in-class editor which does its very best to get out of the way, and let you focus on your content. Don\'t let its minimal looks fool you, though, beneath the surface lies a powerful editing toolset designed to accommodate the extensive needs of modern creators.</p><p>For many, the base canvas of the Ghost editor will feel familiar. You can start writing as you would expect, highlight content to access the toolbar you would expect, and generally use all of the keyboard shortcuts you would expect.</p><p>Our main focus in building the Ghost editor is to try and make as many things that you hope/expect might work: actually work. </p><ul><li>You can copy and paste raw content from web pages, and Ghost will do its best to correctly preserve the formatting. </li><li>Pasting an image from your clipboard will upload inline.</li><li>Pasting a social media URL will automatically create an embed.</li><li>Highlight a word in the editor and paste a URL from your clipboard on top: Ghost will turn it into a link.</li><li>You can also paste (or write!) Markdown and Ghost will usually be able to auto-convert it into fully editable, formatted content.</li></ul><figure class=\"kg-card kg-image-card kg-width-wide kg-card-hascaption\"><img src=\"https://static.ghost.org/v4.0.0/images/editor.png\" class=\"kg-image\" alt loading=\"lazy\" width=\"3182\" height=\"1500\"><figcaption>The Ghost editor. Also available in dark-mode, for late night writing sessions.</figcaption></figure><p>The goal, as much as possible, is for things to work so that you don\'t have to <em>think</em> so much about the editor. You won\'t find any disastrous \"block builders\" here, where you have to open 6 submenus and choose from 18 different but identical alignment options. That\'s not what Ghost is about.</p><p>What you will find though, is dynamic cards which allow you to embed rich media into your posts and create beautifully laid out stories.</p><h2 id=\"using-cards\">Using cards</h2><p>You can insert dynamic cards inside post content using the <code>+</code> button, which appears on new lines, or by typing <code>/</code> on a new line to trigger the card menu. Many of the choices are simple and intuitive, like bookmark cards, which allow you to create rich links with embedded structured data:</p><figure class=\"kg-card kg-bookmark-card\"><a class=\"kg-bookmark-container\" href=\"https://opensubscriptionplatforms.com/\"><div class=\"kg-bookmark-content\"><div class=\"kg-bookmark-title\">Open Subscription Platforms</div><div class=\"kg-bookmark-description\">A shared movement for independent subscription data.</div><div class=\"kg-bookmark-metadata\"><img class=\"kg-bookmark-icon\" src=\"https://opensubscriptionplatforms.com/images/favicon.png\"><span class=\"kg-bookmark-author\">Open Subscription Platforms</span></div></div><div class=\"kg-bookmark-thumbnail\"><img src=\"https://opensubscriptionplatforms.com/images/osp-card.png\"></div></a></figure><p>or embed cards which make it easy to insert content you want to share with your audience, from external services:</p><figure class=\"kg-card kg-embed-card\"><iframe width=\"200\" height=\"113\" src=\"https://www.youtube.com/embed/hmH3XMlms8E?feature=oembed\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe></figure><p>But, dig a little deeper, and you\'ll also find more advanced cards, like one that only shows up in email newsletters (great for personalized introductions) and a comprehensive set of specialized cards for different types of images and galleries.</p><blockquote>Once you  start mixing text and image cards creatively, the whole narrative of the story changes. Suddenly, you\'re working in a new format.</blockquote><figure class=\"kg-card kg-image-card kg-width-full\"><img src=\"https://static.ghost.org/v4.0.0/images/andreas-selter-xSMqGH7gi6o-unsplash.jpg\" class=\"kg-image\" alt loading=\"lazy\" width=\"6000\" height=\"4000\"></figure><p>As it turns out, sometimes pictures and a thousand words go together really well. Telling people a great story often has much more impact if they can feel, even for a moment, as though they were right there with you.</p><figure class=\"kg-card kg-gallery-card kg-width-wide\"><div class=\"kg-gallery-container\"><div class=\"kg-gallery-row\"><div class=\"kg-gallery-image\"><img src=\"https://static.ghost.org/v4.0.0/images/andreas-selter-e4yK8QQlZa0-unsplash.jpg\" width=\"4572\" height=\"3048\" loading=\"lazy\" alt></div><div class=\"kg-gallery-image\"><img src=\"https://static.ghost.org/v4.0.0/images/steve-carter-Ixp4YhCKZkI-unsplash.jpg\" width=\"4032\" height=\"2268\" loading=\"lazy\" alt></div></div></div></figure><figure class=\"kg-card kg-image-card kg-width-wide\"><img src=\"https://static.ghost.org/v4.0.0/images/lukasz-szmigiel-jFCViYFYcus-unsplash.jpg\" class=\"kg-image\" alt loading=\"lazy\" width=\"2560\" height=\"1705\"></figure><figure class=\"kg-card kg-gallery-card kg-width-wide kg-card-hascaption\"><div class=\"kg-gallery-container\"><div class=\"kg-gallery-row\"><div class=\"kg-gallery-image\"><img src=\"https://static.ghost.org/v4.0.0/images/jd-mason-hPiEFq6-Eto-unsplash.jpg\" width=\"5184\" height=\"3888\" loading=\"lazy\" alt></div><div class=\"kg-gallery-image\"><img src=\"https://static.ghost.org/v4.0.0/images/jp-valery-OBpOP9GVH9U-unsplash.jpg\" width=\"5472\" height=\"3648\" loading=\"lazy\" alt></div></div></div><figcaption>Peaceful places</figcaption></figure><p>Galleries and image cards can be combined in so many different ways — the only limit is your imagination.</p><h2 id=\"build-workflows-with-snippets\">Build workflows with snippets</h2><p>One of the most powerful features of the Ghost editor is the ability to create and re-use content snippets. If you\'ve ever used an email client with a concept of <em>saved replies</em> then this will be immediately intuitive.</p><p>To create a snippet, select a piece of content in the editor that you\'d like to re-use in future, then click on the snippet icon in the toolbar. Give your snippet a name, and you\'re all done. Now your snippet will be available from within the card menu, or you can search for it directly using the <code>/</code> command.</p><p>This works really well for saving images you might want to use often, like a company logo or team photo, links to resources you find yourself often linking to, or introductions and passages that you want to remember.</p><figure class=\"kg-card kg-image-card kg-width-wide\"><img src=\"https://static.ghost.org/v4.0.0/images/createsnippet.png\" class=\"kg-image\" alt loading=\"lazy\" width=\"2282\" height=\"1272\"></figure><p>You can even build entire post templates or outlines to create a quick, re-usable workflow for publishing over time. Or build custom design elements for your post with an HTML card, and use a snippet to insert it.</p><p>Once you get a few useful snippets set up, it\'s difficult to go back to the old way of diving through media libraries and trawling for that one thing you know you used somewhere that one time.</p><hr><h2 id=\"publishing-and-newsletters-the-easy-way\">Publishing and newsletters the easy way</h2><p>When you\'re ready to publish, Ghost makes it as simple as possible to deliver your new post to all your existing members. Just hit the <em>Preview</em> link and you\'ll get a chance to see what your content looks like on Web, Mobile, Email and Social.</p><figure class=\"kg-card kg-image-card kg-width-wide\"><img src=\"https://static.ghost.org/v4.0.0/images/preview.png\" class=\"kg-image\" alt loading=\"lazy\" width=\"3166\" height=\"2224\"></figure><p>You can send yourself a test newsletter to make sure everything looks good in your email client, and then hit the <em>Publish</em> button to decide who to deliver it to.</p><p>Ghost comes with a streamlined, optimized email newsletter template that has settings built-in for you to customize the colors and typography. We\'ve spent countless hours refining the template to make sure it works great across all email clients, and performs well for email deliverability.</p><p>So, you don\'t need to fight the awful process of building a custom email template from scratch. It\'s all done already!</p><hr><p>The Ghost editor is powerful enough to do whatever you want it to do. With a little exploration, you\'ll be up and running in no time.</p>','6091ec1c517db00001e536e9','Ghost comes with a best-in-class editor which does its very best to get out of\nthe way, and let you focus on your content. Don\'t let its minimal looks fool\nyou, though, beneath the surface lies a powerful editing toolset designed to\naccommodate the extensive needs of modern creators.\n\nFor many, the base canvas of the Ghost editor will feel familiar. You can start\nwriting as you would expect, highlight content to access the toolbar you would\nexpect, and generally use all of the keyboard shortcuts you would expect.\n\nOur main focus in building the Ghost editor is to try and make as many things\nthat you hope/expect might work: actually work. \n\n * You can copy and paste raw content from web pages, and Ghost will do its best\n   to correctly preserve the formatting. \n * Pasting an image from your clipboard will upload inline.\n * Pasting a social media URL will automatically create an embed.\n * Highlight a word in the editor and paste a URL from your clipboard on top:\n   Ghost will turn it into a link.\n * You can also paste (or write!) Markdown and Ghost will usually be able to\n   auto-convert it into fully editable, formatted content.\n\nThe Ghost editor. Also available in dark-mode, for late night writing sessions.\nThe goal, as much as possible, is for things to work so that you don\'t have to \nthink so much about the editor. You won\'t find any disastrous \"block builders\"\nhere, where you have to open 6 submenus and choose from 18 different but\nidentical alignment options. That\'s not what Ghost is about.\n\nWhat you will find though, is dynamic cards which allow you to embed rich media\ninto your posts and create beautifully laid out stories.\n\nUsing cards\nYou can insert dynamic cards inside post content using the + button, which\nappears on new lines, or by typing / on a new line to trigger the card menu.\nMany of the choices are simple and intuitive, like bookmark cards, which allow\nyou to create rich links with embedded structured data:\n\nOpen Subscription PlatformsA shared movement for independent subscription data.\nOpen Subscription Platforms [https://opensubscriptionplatforms.com/]or embed\ncards which make it easy to insert content you want to share with your audience,\nfrom external services:\n\nBut, dig a little deeper, and you\'ll also find more advanced cards, like one\nthat only shows up in email newsletters (great for personalized introductions)\nand a comprehensive set of specialized cards for different types of images and\ngalleries.\n\n> Once you  start mixing text and image cards creatively, the whole narrative of\nthe story changes. Suddenly, you\'re working in a new format.\nAs it turns out, sometimes pictures and a thousand words go together really\nwell. Telling people a great story often has much more impact if they can feel,\neven for a moment, as though they were right there with you.\n\nPeaceful placesGalleries and image cards can be combined in so many different\nways — the only limit is your imagination.\n\nBuild workflows with snippets\nOne of the most powerful features of the Ghost editor is the ability to create\nand re-use content snippets. If you\'ve ever used an email client with a concept\nof saved replies then this will be immediately intuitive.\n\nTo create a snippet, select a piece of content in the editor that you\'d like to\nre-use in future, then click on the snippet icon in the toolbar. Give your\nsnippet a name, and you\'re all done. Now your snippet will be available from\nwithin the card menu, or you can search for it directly using the / command.\n\nThis works really well for saving images you might want to use often, like a\ncompany logo or team photo, links to resources you find yourself often linking\nto, or introductions and passages that you want to remember.\n\nYou can even build entire post templates or outlines to create a quick,\nre-usable workflow for publishing over time. Or build custom design elements for\nyour post with an HTML card, and use a snippet to insert it.\n\nOnce you get a few useful snippets set up, it\'s difficult to go back to the old\nway of diving through media libraries and trawling for that one thing you know\nyou used somewhere that one time.\n\n\n--------------------------------------------------------------------------------\n\nPublishing and newsletters the easy way\nWhen you\'re ready to publish, Ghost makes it as simple as possible to deliver\nyour new post to all your existing members. Just hit the Preview link and you\'ll\nget a chance to see what your content looks like on Web, Mobile, Email and\nSocial.\n\nYou can send yourself a test newsletter to make sure everything looks good in\nyour email client, and then hit the Publish button to decide who to deliver it\nto.\n\nGhost comes with a streamlined, optimized email newsletter template that has\nsettings built-in for you to customize the colors and typography. We\'ve spent\ncountless hours refining the template to make sure it works great across all\nemail clients, and performs well for email deliverability.\n\nSo, you don\'t need to fight the awful process of building a custom email\ntemplate from scratch. It\'s all done already!\n\n\n--------------------------------------------------------------------------------\n\nThe Ghost editor is powerful enough to do whatever you want it to do. With a\nlittle exploration, you\'ll be up and running in no time.','https://static.ghost.org/v4.0.0/images/writing-posts-with-ghost.png',0,'post','published',NULL,'public','none','5951f5fca366002ebd5dbef7','2021-05-05 00:51:40','1','2021-05-05 00:51:40','1','2021-05-05 00:51:44','1','A full overview of all the features built into the Ghost editor, including powerful workflow automations to speed up your creative process.',NULL,NULL,NULL,NULL),('6091ec1c517db00001e536eb','8fb3adce-0dcc-4274-bc94-6c6f6d3baf6c','Customizing your brand and design settings','design','{\"version\":\"0.3.1\",\"atoms\":[],\"cards\":[[\"image\",{\"src\":\"https://static.ghost.org/v4.0.0/images/brandsettings.png\",\"width\":3456,\"height\":2338,\"cardWidth\":\"wide\",\"caption\":\"Ghost Admin → Settings → Branding\"}],[\"image\",{\"src\":\"https://static.ghost.org/v4.0.0/images/themesettings.png\",\"width\":3208,\"height\":1618,\"cardWidth\":\"wide\",\"caption\":\"Ghost Admin → Settings → Theme\"}],[\"code\",{\"code\":\"{{#post}}\\n<article class=\\\"article {{post_class}}\\\">\\n\\n    <h1>{{title}}</h1>\\n    \\n    {{#if feature_image}}\\n    \\t<img src=\\\"{{feature_image}}\\\" alt=\\\"Feature image\\\" />\\n    {{/if}}\\n    \\n    {{content}}\\n\\n</article>\\n{{/post}}\",\"language\":\"handlebars\",\"caption\":\"A snippet from a post template\"}]],\"markups\":[[\"a\",[\"href\",\"__GHOST_URL__/welcome/\"]],[\"strong\"],[\"em\"],[\"a\",[\"href\",\"https://ghost.org/themes/\"]],[\"a\",[\"href\",\"https://github.com/tryghost/casper/\"]],[\"a\",[\"href\",\"https://ghost.org/docs/themes/\"]]],\"sections\":[[1,\"p\",[[0,[],0,\"As discussed in the \"],[0,[0],1,\"introduction\"],[0,[],0,\" post, one of the best things about Ghost is just how much you can customize to turn your site into something unique. Everything about your layout and design can be changed, so you\'re not stuck with yet another clone of a social network profile.\"]]],[1,\"p\",[[0,[],0,\"How far you want to go with customization is completely up to you, there\'s no right or wrong approach! The majority of people use one of Ghost\'s built-in themes to get started, and then progress to something more bespoke later on as their site grows. \"]]],[1,\"p\",[[0,[],0,\"The best way to get started is with Ghost\'s branding settings, where you can set up colors, images and logos to fit with your brand.\"]]],[10,0],[1,\"p\",[[0,[],0,\"Any Ghost theme that\'s up to date and compatible with Ghost 4.0 and higher will reflect your branding settings in the preview window, so you can see what your site will look like as you experiment with different options.\"]]],[1,\"p\",[[0,[],0,\"When selecting an accent color, try to choose something which will contrast well with white text. Many themes will use your accent color as the background for buttons, headers and navigational elements. Vibrant colors with a darker hue tend to work best, as a general rule.\"]]],[1,\"h2\",[[0,[],0,\"Installing Ghost themes\"]]],[1,\"p\",[[0,[],0,\"By default, new sites are created with Ghost\'s friendly publication theme, called Casper. Everything in Casper is optimized to work for the most common types of blog, newsletter and publication that people create with Ghost — so it\'s a perfect place to start.\"]]],[1,\"p\",[[0,[],0,\"However, there are hundreds of different themes available to install, so you can pick out a look and feel that suits you best.\"]]],[10,1],[1,\"p\",[[0,[],0,\"Inside Ghost\'s theme settings you\'ll find 4 more official themes that can be directly installed and activated. Each theme is suited to slightly different use-cases.\"]]],[3,\"ul\",[[[0,[1],1,\"Casper\"],[0,[],0,\" \"],[0,[2],1,\"(default)\"],[0,[],0,\" — Made for all sorts of blogs and newsletters\"]],[[0,[1],1,\"Edition\"],[0,[],0,\" — A beautiful minimal template for newsletter authors\"]],[[0,[1],1,\"Alto\"],[0,[],0,\" — A slick news/magazine style design for creators\"]],[[0,[1],1,\"London\"],[0,[],0,\" — A light photography theme with a bold grid\"]],[[0,[1],1,\"Ease\"],[0,[],0,\" — A library theme for organizing large content archives\"]]]],[1,\"p\",[[0,[],0,\"And if none of those feel quite right, head on over to the \"],[0,[3],1,\"Ghost Marketplace\"],[0,[],0,\", where you\'ll find a huge variety of both free and premium themes.\"]]],[1,\"h2\",[[0,[],0,\"Building something custom\"]]],[1,\"p\",[[0,[],0,\"Finally, if you want something completely bespoke for your site, you can always build a custom theme from scratch and upload it to your site.\"]]],[1,\"p\",[[0,[],0,\"Ghost\'s theming template files are very easy to work with, and can be picked up in the space of a few hours by anyone who has just a little bit of knowledge of HTML and CSS. Templates from other platforms can also be ported to Ghost with relatively little effort.\"]]],[1,\"p\",[[0,[],0,\"If you want to take a quick look at the theme syntax to see what it\'s like, you can \"],[0,[4],1,\"browse through the files of the default Casper theme\"],[0,[],0,\". We\'ve added tons of inline code comments to make it easy to learn, and the structure is very readable.\"]]],[10,2],[1,\"p\",[[0,[],0,\"See? Not that scary! But still completely optional. \"]]],[1,\"p\",[[0,[],0,\"If you\'re interested in creating your own Ghost theme, check out our extensive \"],[0,[5],1,\"theme documentation\"],[0,[],0,\" for a full guide to all the different template variables and helpers which are available.\"]]]],\"ghostVersion\":\"4.0\"}','<p>As discussed in the <a href=\"__GHOST_URL__/welcome/\">introduction</a> post, one of the best things about Ghost is just how much you can customize to turn your site into something unique. Everything about your layout and design can be changed, so you\'re not stuck with yet another clone of a social network profile.</p><p>How far you want to go with customization is completely up to you, there\'s no right or wrong approach! The majority of people use one of Ghost\'s built-in themes to get started, and then progress to something more bespoke later on as their site grows. </p><p>The best way to get started is with Ghost\'s branding settings, where you can set up colors, images and logos to fit with your brand.</p><figure class=\"kg-card kg-image-card kg-width-wide kg-card-hascaption\"><img src=\"https://static.ghost.org/v4.0.0/images/brandsettings.png\" class=\"kg-image\" alt loading=\"lazy\" width=\"3456\" height=\"2338\"><figcaption>Ghost Admin → Settings → Branding</figcaption></figure><p>Any Ghost theme that\'s up to date and compatible with Ghost 4.0 and higher will reflect your branding settings in the preview window, so you can see what your site will look like as you experiment with different options.</p><p>When selecting an accent color, try to choose something which will contrast well with white text. Many themes will use your accent color as the background for buttons, headers and navigational elements. Vibrant colors with a darker hue tend to work best, as a general rule.</p><h2 id=\"installing-ghost-themes\">Installing Ghost themes</h2><p>By default, new sites are created with Ghost\'s friendly publication theme, called Casper. Everything in Casper is optimized to work for the most common types of blog, newsletter and publication that people create with Ghost — so it\'s a perfect place to start.</p><p>However, there are hundreds of different themes available to install, so you can pick out a look and feel that suits you best.</p><figure class=\"kg-card kg-image-card kg-width-wide kg-card-hascaption\"><img src=\"https://static.ghost.org/v4.0.0/images/themesettings.png\" class=\"kg-image\" alt loading=\"lazy\" width=\"3208\" height=\"1618\"><figcaption>Ghost Admin → Settings → Theme</figcaption></figure><p>Inside Ghost\'s theme settings you\'ll find 4 more official themes that can be directly installed and activated. Each theme is suited to slightly different use-cases.</p><ul><li><strong>Casper</strong> <em>(default)</em> — Made for all sorts of blogs and newsletters</li><li><strong>Edition</strong> — A beautiful minimal template for newsletter authors</li><li><strong>Alto</strong> — A slick news/magazine style design for creators</li><li><strong>London</strong> — A light photography theme with a bold grid</li><li><strong>Ease</strong> — A library theme for organizing large content archives</li></ul><p>And if none of those feel quite right, head on over to the <a href=\"https://ghost.org/themes/\">Ghost Marketplace</a>, where you\'ll find a huge variety of both free and premium themes.</p><h2 id=\"building-something-custom\">Building something custom</h2><p>Finally, if you want something completely bespoke for your site, you can always build a custom theme from scratch and upload it to your site.</p><p>Ghost\'s theming template files are very easy to work with, and can be picked up in the space of a few hours by anyone who has just a little bit of knowledge of HTML and CSS. Templates from other platforms can also be ported to Ghost with relatively little effort.</p><p>If you want to take a quick look at the theme syntax to see what it\'s like, you can <a href=\"https://github.com/tryghost/casper/\">browse through the files of the default Casper theme</a>. We\'ve added tons of inline code comments to make it easy to learn, and the structure is very readable.</p><figure class=\"kg-card kg-code-card\"><pre><code class=\"language-handlebars\">{{#post}}\n&lt;article class=\"article {{post_class}}\"&gt;\n\n    &lt;h1&gt;{{title}}&lt;/h1&gt;\n    \n    {{#if feature_image}}\n    	&lt;img src=\"{{feature_image}}\" alt=\"Feature image\" /&gt;\n    {{/if}}\n    \n    {{content}}\n\n&lt;/article&gt;\n{{/post}}</code></pre><figcaption>A snippet from a post template</figcaption></figure><p>See? Not that scary! But still completely optional. </p><p>If you\'re interested in creating your own Ghost theme, check out our extensive <a href=\"https://ghost.org/docs/themes/\">theme documentation</a> for a full guide to all the different template variables and helpers which are available.</p>','6091ec1c517db00001e536eb','As discussed in the introduction [__GHOST_URL__/welcome/] post, one of the best\nthings about Ghost is just how much you can customize to turn your site into\nsomething unique. Everything about your layout and design can be changed, so\nyou\'re not stuck with yet another clone of a social network profile.\n\nHow far you want to go with customization is completely up to you, there\'s no\nright or wrong approach! The majority of people use one of Ghost\'s built-in\nthemes to get started, and then progress to something more bespoke later on as\ntheir site grows. \n\nThe best way to get started is with Ghost\'s branding settings, where you can set\nup colors, images and logos to fit with your brand.\n\nGhost Admin → Settings → BrandingAny Ghost theme that\'s up to date and\ncompatible with Ghost 4.0 and higher will reflect your branding settings in the\npreview window, so you can see what your site will look like as you experiment\nwith different options.\n\nWhen selecting an accent color, try to choose something which will contrast well\nwith white text. Many themes will use your accent color as the background for\nbuttons, headers and navigational elements. Vibrant colors with a darker hue\ntend to work best, as a general rule.\n\nInstalling Ghost themes\nBy default, new sites are created with Ghost\'s friendly publication theme,\ncalled Casper. Everything in Casper is optimized to work for the most common\ntypes of blog, newsletter and publication that people create with Ghost — so\nit\'s a perfect place to start.\n\nHowever, there are hundreds of different themes available to install, so you can\npick out a look and feel that suits you best.\n\nGhost Admin → Settings → ThemeInside Ghost\'s theme settings you\'ll find 4 more\nofficial themes that can be directly installed and activated. Each theme is\nsuited to slightly different use-cases.\n\n * Casper (default) — Made for all sorts of blogs and newsletters\n * Edition — A beautiful minimal template for newsletter authors\n * Alto — A slick news/magazine style design for creators\n * London — A light photography theme with a bold grid\n * Ease — A library theme for organizing large content archives\n\nAnd if none of those feel quite right, head on over to the Ghost Marketplace\n[https://ghost.org/themes/], where you\'ll find a huge variety of both free and\npremium themes.\n\nBuilding something custom\nFinally, if you want something completely bespoke for your site, you can always\nbuild a custom theme from scratch and upload it to your site.\n\nGhost\'s theming template files are very easy to work with, and can be picked up\nin the space of a few hours by anyone who has just a little bit of knowledge of\nHTML and CSS. Templates from other platforms can also be ported to Ghost with\nrelatively little effort.\n\nIf you want to take a quick look at the theme syntax to see what it\'s like, you\ncan browse through the files of the default Casper theme\n[https://github.com/tryghost/casper/]. We\'ve added tons of inline code comments\nto make it easy to learn, and the structure is very readable.\n\n{{#post}}\n<article class=\"article {{post_class}}\">\n\n    <h1>{{title}}</h1>\n    \n    {{#if feature_image}}\n    	<img src=\"{{feature_image}}\" alt=\"Feature image\" />\n    {{/if}}\n    \n    {{content}}\n\n</article>\n{{/post}}\n\nA snippet from a post templateSee? Not that scary! But still completely\noptional. \n\nIf you\'re interested in creating your own Ghost theme, check out our extensive \ntheme documentation [https://ghost.org/docs/themes/] for a full guide to all the\ndifferent template variables and helpers which are available.','https://static.ghost.org/v4.0.0/images/publishing-options.png',0,'post','published',NULL,'public','none','5951f5fca366002ebd5dbef7','2021-05-05 00:51:40','1','2021-05-05 00:51:40','1','2021-05-05 00:51:45','1','How to tweak a few settings in Ghost to transform your site from a generic template to a custom brand with style and personality.',NULL,NULL,NULL,NULL),('6091ec1c517db00001e536ed','1c075e33-e9c4-4fcd-988c-d9d81b952d39','Start here for a quick overview of everything you need to know','welcome','{\"version\":\"0.3.1\",\"atoms\":[],\"cards\":[[\"hr\",{}],[\"hr\",{}]],\"markups\":[[\"strong\"],[\"a\",[\"href\",\"__GHOST_URL__/design/\"]],[\"a\",[\"href\",\"__GHOST_URL__/write/\"]],[\"a\",[\"href\",\"__GHOST_URL__/portal/\"]],[\"a\",[\"href\",\"__GHOST_URL__/sell/\"]],[\"a\",[\"href\",\"__GHOST_URL__/grow/\"]],[\"a\",[\"href\",\"__GHOST_URL__/integrations/\"]],[\"a\",[\"href\",\"https://ghost.org/blog/\"]],[\"a\",[\"href\",\"https://ghost.org/pricing/\"]],[\"em\"],[\"a\",[\"href\",\"https://forum.ghost.org\"]]],\"sections\":[[1,\"p\",[[0,[0],1,\"Hey therex\"],[0,[],0,\", welcome to your new home on the web! \"]]],[1,\"p\",[[0,[],0,\"Unlike social networks, this one is all yours. Publish your work on a custom domain, invite your audience to subscribe, send them new content by email newsletter, and offer premium subscriptions to generate sustainable recurring revenue to fund your work. \"]]],[1,\"p\",[[0,[],0,\"Ghost is an independent, open source app, which means you can customize absolutely everything. Inside the admin area, you\'ll find straightforward controls for changing themes, colors, navigation, logos and settings — so you can set your site up just how you like it. No technical knowledge required.\"]]],[1,\"p\",[[0,[],0,\"If you\'re feeling a little more adventurous, there\'s really no limit to what\'s possible. With just a little bit of HTML and CSS you can modify or build your very own theme from scratch, or connect to Zapier to explore advanced integrations. Advanced developers can go even further and build entirely custom workflows using the Ghost API.\"]]],[1,\"p\",[[0,[],0,\"This level of customization means that Ghost grows with you. It\'s easy to get started, but there\'s always another level of what\'s possible. So, you won\'t find yourself outgrowing the app in a few months time and wishing you\'d chosen something more powerful!\"]]],[10,0],[1,\"p\",[[0,[],0,\"For now, you\'re probably just wondering what to do first. To help get you going as quickly as possible, we\'ve populated your site with starter content (like this post!) covering all the key concepts and features of the product.\"]]],[1,\"p\",[[0,[],0,\"You\'ll find an outline of all the different topics below, with links to each section so you can explore the parts that interest you most.\"]]],[1,\"p\",[[0,[],0,\"Once you\'re ready to begin publishing and want to clear out these starter posts, you can delete the \\\"Ghost\\\" staff user. Deleting an author will automatically remove all of their posts, leaving you with a clean blank canvas.\"]]],[1,\"h2\",[[0,[],0,\"Your guide to Ghost\"]]],[3,\"ul\",[[[0,[1],1,\"Customizing your brand and site settings\"]],[[0,[2],1,\"Writing & managing content, an advanced guide for creators\"]],[[0,[3],1,\"Building your audience with subscriber signups\"]],[[0,[4],1,\"Selling premium memberships with recurring revenue\"]],[[0,[5],1,\"How to grow your business around an audience\"]],[[0,[6],1,\"Setting up custom integrations and apps\"]]]],[1,\"p\",[[0,[],0,\"If you get through all those and you\'re hungry for more, you can find an extensive library of content for creators over on \"],[0,[7],1,\"the Ghost blog\"],[0,[],0,\".\"]]],[10,1],[1,\"h2\",[[0,[],0,\"Getting help\"]]],[1,\"p\",[[0,[],0,\"If you need help, \"],[0,[8],1,\"Ghost(Pro)\"],[0,[],0,\" customers can always reach our full-time support team by clicking on the \"],[0,[9],1,\"Ghost(Pro)\"],[0,[],0,\" link inside their admin panel.\"]]],[1,\"p\",[[0,[],0,\"If you\'re a developer working with the codebase in a self-managed install, check out our \"],[0,[10],1,\"developer community forum\"],[0,[],0,\" to chat with other users.\"]]],[1,\"p\",[[0,[],0,\"Have fun!\"]]]],\"ghostVersion\":\"4.0\"}','<p><strong>Hey therex</strong>, welcome to your new home on the web! </p><p>Unlike social networks, this one is all yours. Publish your work on a custom domain, invite your audience to subscribe, send them new content by email newsletter, and offer premium subscriptions to generate sustainable recurring revenue to fund your work. </p><p>Ghost is an independent, open source app, which means you can customize absolutely everything. Inside the admin area, you\'ll find straightforward controls for changing themes, colors, navigation, logos and settings — so you can set your site up just how you like it. No technical knowledge required.</p><p>If you\'re feeling a little more adventurous, there\'s really no limit to what\'s possible. With just a little bit of HTML and CSS you can modify or build your very own theme from scratch, or connect to Zapier to explore advanced integrations. Advanced developers can go even further and build entirely custom workflows using the Ghost API.</p><p>This level of customization means that Ghost grows with you. It\'s easy to get started, but there\'s always another level of what\'s possible. So, you won\'t find yourself outgrowing the app in a few months time and wishing you\'d chosen something more powerful!</p><hr><p>For now, you\'re probably just wondering what to do first. To help get you going as quickly as possible, we\'ve populated your site with starter content (like this post!) covering all the key concepts and features of the product.</p><p>You\'ll find an outline of all the different topics below, with links to each section so you can explore the parts that interest you most.</p><p>Once you\'re ready to begin publishing and want to clear out these starter posts, you can delete the \"Ghost\" staff user. Deleting an author will automatically remove all of their posts, leaving you with a clean blank canvas.</p><h2 id=\"your-guide-to-ghost\">Your guide to Ghost</h2><ul><li><a href=\"__GHOST_URL__/design/\">Customizing your brand and site settings</a></li><li><a href=\"__GHOST_URL__/write/\">Writing &amp; managing content, an advanced guide for creators</a></li><li><a href=\"__GHOST_URL__/portal/\">Building your audience with subscriber signups</a></li><li><a href=\"__GHOST_URL__/sell/\">Selling premium memberships with recurring revenue</a></li><li><a href=\"__GHOST_URL__/grow/\">How to grow your business around an audience</a></li><li><a href=\"__GHOST_URL__/integrations/\">Setting up custom integrations and apps</a></li></ul><p>If you get through all those and you\'re hungry for more, you can find an extensive library of content for creators over on <a href=\"https://ghost.org/blog/\">the Ghost blog</a>.</p><hr><h2 id=\"getting-help\">Getting help</h2><p>If you need help, <a href=\"https://ghost.org/pricing/\">Ghost(Pro)</a> customers can always reach our full-time support team by clicking on the <em>Ghost(Pro)</em> link inside their admin panel.</p><p>If you\'re a developer working with the codebase in a self-managed install, check out our <a href=\"https://forum.ghost.org\">developer community forum</a> to chat with other users.</p><p>Have fun!</p>','6091ec1c517db00001e536ed','Hey therex, welcome to your new home on the web! \n\nUnlike social networks, this one is all yours. Publish your work on a custom\ndomain, invite your audience to subscribe, send them new content by email\nnewsletter, and offer premium subscriptions to generate sustainable recurring\nrevenue to fund your work. \n\nGhost is an independent, open source app, which means you can customize\nabsolutely everything. Inside the admin area, you\'ll find straightforward\ncontrols for changing themes, colors, navigation, logos and settings — so you\ncan set your site up just how you like it. No technical knowledge required.\n\nIf you\'re feeling a little more adventurous, there\'s really no limit to what\'s\npossible. With just a little bit of HTML and CSS you can modify or build your\nvery own theme from scratch, or connect to Zapier to explore advanced\nintegrations. Advanced developers can go even further and build entirely custom\nworkflows using the Ghost API.\n\nThis level of customization means that Ghost grows with you. It\'s easy to get\nstarted, but there\'s always another level of what\'s possible. So, you won\'t find\nyourself outgrowing the app in a few months time and wishing you\'d chosen\nsomething more powerful!\n\n\n--------------------------------------------------------------------------------\n\nFor now, you\'re probably just wondering what to do first. To help get you going\nas quickly as possible, we\'ve populated your site with starter content (like\nthis post!) covering all the key concepts and features of the product.\n\nYou\'ll find an outline of all the different topics below, with links to each\nsection so you can explore the parts that interest you most.\n\nOnce you\'re ready to begin publishing and want to clear out these starter posts,\nyou can delete the \"Ghost\" staff user. Deleting an author will automatically\nremove all of their posts, leaving you with a clean blank canvas.\n\nYour guide to Ghost\n * Customizing your brand and site settings [__GHOST_URL__/design/]\n * Writing & managing content, an advanced guide for creators\n   [__GHOST_URL__/write/]\n * Building your audience with subscriber signups\n   [__GHOST_URL__/portal/]\n * Selling premium memberships with recurring revenue\n   [__GHOST_URL__/sell/]\n * How to grow your business around an audience [__GHOST_URL__/grow/]\n * Setting up custom integrations and apps [__GHOST_URL__/integrations/]\n\nIf you get through all those and you\'re hungry for more, you can find an\nextensive library of content for creators over on the Ghost blog\n[https://ghost.org/blog/].\n\n\n--------------------------------------------------------------------------------\n\nGetting help\nIf you need help, Ghost(Pro) [https://ghost.org/pricing/] customers can always\nreach our full-time support team by clicking on the Ghost(Pro) link inside their\nadmin panel.\n\nIf you\'re a developer working with the codebase in a self-managed install, check\nout our developer community forum [https://forum.ghost.org] to chat with other\nusers.\n\nHave fun!','__GHOST_URL__/content/images/2021/05/knowledge.jpg',1,'post','published',NULL,'public','none','5951f5fca366002ebd5dbef7','2021-05-05 00:51:40','1','2021-05-05 01:07:05','1','2021-05-05 00:51:46','1','We\'ve crammed the most important information to help you get started with Ghost into this one post. It\'s your cheat-sheet to get started, and your shortcut to advanced features.',NULL,NULL,NULL,NULL),('6091ec1d517db00001e536ef','ec9bc97d-c09c-4872-a217-22eb68b8372c','About this site','about','{\"version\":\"0.3.1\",\"atoms\":[],\"cards\":[],\"markups\":[[\"strong\"],[\"code\"]],\"sections\":[[1,\"p\",[[0,[],0,\"Unlike posts, pages in Ghost don\'t appear the main feed. They\'re separate, individual pages which only show up when you link to them. Great for content which is important, but separate from your usual posts.\"]]],[1,\"p\",[[0,[],0,\"An about page is a great example of one you might want to set up early on so people can find out more about you, and what you do. Why should people subscribe to your site and become a member? Details help!\"]]],[1,\"blockquote\",[[0,[0],1,\"Tip: \"],[0,[],0,\"If you\'re reading any post or page on your site and you notice something you want to edit, you can add \"],[0,[1],1,\"/edit\"],[0,[],0,\" to the end of the URL – and you\'ll be taken directly to the Ghost editor.\"]]],[1,\"p\",[[0,[],0,\"Now tell the world what your site is all about.\"]]]],\"ghostVersion\":\"4.0\"}','<p>Unlike posts, pages in Ghost don\'t appear the main feed. They\'re separate, individual pages which only show up when you link to them. Great for content which is important, but separate from your usual posts.</p><p>An about page is a great example of one you might want to set up early on so people can find out more about you, and what you do. Why should people subscribe to your site and become a member? Details help!</p><blockquote><strong>Tip: </strong>If you\'re reading any post or page on your site and you notice something you want to edit, you can add <code>/edit</code> to the end of the URL – and you\'ll be taken directly to the Ghost editor.</blockquote><p>Now tell the world what your site is all about.</p>','6091ec1d517db00001e536ef','Unlike posts, pages in Ghost don\'t appear the main feed. They\'re separate,\nindividual pages which only show up when you link to them. Great for content\nwhich is important, but separate from your usual posts.\n\nAn about page is a great example of one you might want to set up early on so\npeople can find out more about you, and what you do. Why should people subscribe\nto your site and become a member? Details help!\n\n> Tip: If you\'re reading any post or page on your site and you notice something\nyou want to edit, you can add /edit to the end of the URL – and you\'ll be taken\ndirectly to the Ghost editor.\nNow tell the world what your site is all about.',NULL,0,'page','published',NULL,'public','none','5951f5fca366002ebd5dbef7','2021-05-05 00:51:41','1','2021-05-05 00:51:41','1','2021-05-05 00:51:47','1',NULL,NULL,NULL,NULL,NULL),('6091ec1d517db00001e536f1','5d51ac41-d270-43f1-b05b-88a6abbb169c','Contact','contact','{\"version\":\"0.3.1\",\"atoms\":[],\"cards\":[[\"image\",{\"src\":\"https://static.ghost.org/v4.0.0/images/integrations.png\",\"width\":2944,\"height\":1716,\"href\":\"https://ghost.org/integrations/?tag=forms\"}]],\"markups\":[[\"a\",[\"href\",\"https://twitter.com/ghost\"]],[\"a\",[\"href\",\"https://www.facebook.com/ghost\"]],[\"a\",[\"href\",\"https://instagram.com/ghost\"]]],\"sections\":[[1,\"p\",[[0,[],0,\"If you want to set up a contact page for people to be able to reach out to you, the simplest way is to set up a simple page like this and list the different ways people can reach out to you.\"]]],[1,\"h3\",[[0,[],0,\"For example, here\'s how to reach us!\"]]],[3,\"ul\",[[[0,[0],1,\"@Ghost\"],[0,[],0,\" on Twitter\"]],[[0,[1],1,\"@Ghost\"],[0,[],0,\" on Facebook\"]],[[0,[2],1,\"@Ghost\"],[0,[],0,\" on Instagram\"]]]],[1,\"p\",[[0,[],0,\"If you prefer to use a contact form, almost all of the great embedded form services work great with Ghost and are easy to set up:\"]]],[10,0],[1,\"p\",[]]],\"ghostVersion\":\"4.0\"}','<p>If you want to set up a contact page for people to be able to reach out to you, the simplest way is to set up a simple page like this and list the different ways people can reach out to you.</p><h3 id=\"for-example-heres-how-to-reach-us\">For example, here\'s how to reach us!</h3><ul><li><a href=\"https://twitter.com/ghost\">@Ghost</a> on Twitter</li><li><a href=\"https://www.facebook.com/ghost\">@Ghost</a> on Facebook</li><li><a href=\"https://instagram.com/ghost\">@Ghost</a> on Instagram</li></ul><p>If you prefer to use a contact form, almost all of the great embedded form services work great with Ghost and are easy to set up:</p><figure class=\"kg-card kg-image-card\"><a href=\"https://ghost.org/integrations/?tag=forms\"><img src=\"https://static.ghost.org/v4.0.0/images/integrations.png\" class=\"kg-image\" alt loading=\"lazy\" width=\"2944\" height=\"1716\"></a></figure>','6091ec1d517db00001e536f1','If you want to set up a contact page for people to be able to reach out to you,\nthe simplest way is to set up a simple page like this and list the different\nways people can reach out to you.\n\nFor example, here\'s how to reach us!\n * @Ghost [https://twitter.com/ghost] on Twitter\n * @Ghost [https://www.facebook.com/ghost] on Facebook\n * @Ghost [https://instagram.com/ghost] on Instagram\n\nIf you prefer to use a contact form, almost all of the great embedded form\nservices work great with Ghost and are easy to set up:\n\n[https://ghost.org/integrations/?tag=forms]',NULL,0,'page','published',NULL,'public','none','5951f5fca366002ebd5dbef7','2021-05-05 00:51:41','1','2021-05-05 00:51:41','1','2021-05-05 00:51:48','1',NULL,NULL,NULL,NULL,NULL),('6091ec1d517db00001e536f3','a2ca8958-411e-4cee-b7dd-9f31e633a540','Privacy','privacy','{\"version\":\"0.3.1\",\"atoms\":[],\"cards\":[],\"markups\":[],\"sections\":[[1,\"p\",[[0,[],0,\"Wondering how Ghost fares when it comes to privacy and GDPR rules? Good news: Ghost does not use any tracking cookies of any kind.\"]]],[1,\"p\",[[0,[],0,\"You can integrate any products, services, ads or integrations with Ghost yourself if you want to, but it\'s always a good idea to disclose how subscriber data will be used by putting together a privacy page.\"]]]],\"ghostVersion\":\"4.0\"}','<p>Wondering how Ghost fares when it comes to privacy and GDPR rules? Good news: Ghost does not use any tracking cookies of any kind.</p><p>You can integrate any products, services, ads or integrations with Ghost yourself if you want to, but it\'s always a good idea to disclose how subscriber data will be used by putting together a privacy page.</p>','6091ec1d517db00001e536f3','Wondering how Ghost fares when it comes to privacy and GDPR rules? Good news:\nGhost does not use any tracking cookies of any kind.\n\nYou can integrate any products, services, ads or integrations with Ghost\nyourself if you want to, but it\'s always a good idea to disclose how subscriber\ndata will be used by putting together a privacy page.',NULL,0,'page','published',NULL,'public','none','5951f5fca366002ebd5dbef7','2021-05-05 00:51:41','1','2021-05-05 00:51:41','1','2021-05-05 00:51:49','1',NULL,NULL,NULL,NULL,NULL),('6091ec1d517db00001e536f5','41f0c197-d5c5-46dc-822c-8e3963b27e53','Contribute','contribute','{\"version\":\"0.3.1\",\"atoms\":[],\"cards\":[],\"markups\":[[\"a\",[\"href\",\"https://github.com/tryghost\"]],[\"a\",[\"href\",\"https://github.com/sponsors/TryGhost\"]],[\"a\",[\"href\",\"https://opencollective.com/ghost\"]],[\"strong\"]],\"sections\":[[1,\"p\",[[0,[],0,\"Oh hey, you clicked every link of our starter content and even clicked this small link in the footer! If you like Ghost and you\'re enjoying the product so far, we\'d hugely appreciate your support in any way you care to show it.\"]]],[1,\"p\",[[0,[],0,\"Ghost is a non-profit organization, and we give away all our intellectual property as open source software. If you believe in what we do, there are a number of ways you can give us a hand, and we hugely appreciate all of them:\"]]],[3,\"ul\",[[[0,[],0,\"Contribute code via \"],[0,[0],1,\"GitHub\"]],[[0,[],0,\"Contribute financially via \"],[0,[1],1,\"GitHub Sponsors\"]],[[0,[],0,\"Contribute financially via \"],[0,[2],1,\"Open Collective\"]],[[0,[],0,\"Contribute reviews via \"],[0,[3],1,\"writing a blog post\"]],[[0,[],0,\"Contribute good vibes via \"],[0,[3],1,\"telling your friends\"],[0,[],0,\" about us\"]]]],[1,\"p\",[[0,[],0,\"Thanks for checking us out!\"]]]],\"ghostVersion\":\"4.0\"}','<p>Oh hey, you clicked every link of our starter content and even clicked this small link in the footer! If you like Ghost and you\'re enjoying the product so far, we\'d hugely appreciate your support in any way you care to show it.</p><p>Ghost is a non-profit organization, and we give away all our intellectual property as open source software. If you believe in what we do, there are a number of ways you can give us a hand, and we hugely appreciate all of them:</p><ul><li>Contribute code via <a href=\"https://github.com/tryghost\">GitHub</a></li><li>Contribute financially via <a href=\"https://github.com/sponsors/TryGhost\">GitHub Sponsors</a></li><li>Contribute financially via <a href=\"https://opencollective.com/ghost\">Open Collective</a></li><li>Contribute reviews via <strong>writing a blog post</strong></li><li>Contribute good vibes via <strong>telling your friends</strong> about us</li></ul><p>Thanks for checking us out!</p>','6091ec1d517db00001e536f5','Oh hey, you clicked every link of our starter content and even clicked this\nsmall link in the footer! If you like Ghost and you\'re enjoying the product so\nfar, we\'d hugely appreciate your support in any way you care to show it.\n\nGhost is a non-profit organization, and we give away all our intellectual\nproperty as open source software. If you believe in what we do, there are a\nnumber of ways you can give us a hand, and we hugely appreciate all of them:\n\n * Contribute code via GitHub [https://github.com/tryghost]\n * Contribute financially via GitHub Sponsors\n   [https://github.com/sponsors/TryGhost]\n * Contribute financially via Open Collective [https://opencollective.com/ghost]\n * Contribute reviews via writing a blog post\n * Contribute good vibes via telling your friends about us\n\nThanks for checking us out!',NULL,0,'page','published',NULL,'public','none','5951f5fca366002ebd5dbef7','2021-05-05 00:51:41','1','2021-05-05 00:51:41','1','2021-05-05 00:51:50','1',NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts_authors`
--

DROP TABLE IF EXISTS `posts_authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `posts_authors` (
  `id` varchar(24) NOT NULL,
  `post_id` varchar(24) NOT NULL,
  `author_id` varchar(24) NOT NULL,
  `sort_order` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `posts_authors_post_id_foreign` (`post_id`),
  KEY `posts_authors_author_id_foreign` (`author_id`),
  CONSTRAINT `posts_authors_author_id_foreign` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`),
  CONSTRAINT `posts_authors_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts_authors`
--

LOCK TABLES `posts_authors` WRITE;
/*!40000 ALTER TABLE `posts_authors` DISABLE KEYS */;
INSERT INTO `posts_authors` VALUES ('6091ec1c517db00001e536e2','6091ec1c517db00001e536e1','5951f5fca366002ebd5dbef7',0),('6091ec1c517db00001e536e4','6091ec1c517db00001e536e3','5951f5fca366002ebd5dbef7',0),('6091ec1c517db00001e536e6','6091ec1c517db00001e536e5','5951f5fca366002ebd5dbef7',0),('6091ec1c517db00001e536e8','6091ec1c517db00001e536e7','5951f5fca366002ebd5dbef7',0),('6091ec1c517db00001e536ea','6091ec1c517db00001e536e9','5951f5fca366002ebd5dbef7',0),('6091ec1c517db00001e536ec','6091ec1c517db00001e536eb','5951f5fca366002ebd5dbef7',0),('6091ec1c517db00001e536ee','6091ec1c517db00001e536ed','5951f5fca366002ebd5dbef7',0),('6091ec1d517db00001e536f0','6091ec1d517db00001e536ef','5951f5fca366002ebd5dbef7',0),('6091ec1d517db00001e536f2','6091ec1d517db00001e536f1','5951f5fca366002ebd5dbef7',0),('6091ec1d517db00001e536f4','6091ec1d517db00001e536f3','5951f5fca366002ebd5dbef7',0),('6091ec1d517db00001e536f6','6091ec1d517db00001e536f5','5951f5fca366002ebd5dbef7',0);
/*!40000 ALTER TABLE `posts_authors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts_meta`
--

DROP TABLE IF EXISTS `posts_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `posts_meta` (
  `id` varchar(24) NOT NULL,
  `post_id` varchar(24) NOT NULL,
  `og_image` varchar(2000) DEFAULT NULL,
  `og_title` varchar(300) DEFAULT NULL,
  `og_description` varchar(500) DEFAULT NULL,
  `twitter_image` varchar(2000) DEFAULT NULL,
  `twitter_title` varchar(300) DEFAULT NULL,
  `twitter_description` varchar(500) DEFAULT NULL,
  `meta_title` varchar(2000) DEFAULT NULL,
  `meta_description` varchar(2000) DEFAULT NULL,
  `email_subject` varchar(300) DEFAULT NULL,
  `frontmatter` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `posts_meta_post_id_unique` (`post_id`),
  CONSTRAINT `posts_meta_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts_meta`
--

LOCK TABLES `posts_meta` WRITE;
/*!40000 ALTER TABLE `posts_meta` DISABLE KEYS */;
/*!40000 ALTER TABLE `posts_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts_tags`
--

DROP TABLE IF EXISTS `posts_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `posts_tags` (
  `id` varchar(24) NOT NULL,
  `post_id` varchar(24) NOT NULL,
  `tag_id` varchar(24) NOT NULL,
  `sort_order` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `posts_tags_post_id_foreign` (`post_id`),
  KEY `posts_tags_tag_id_foreign` (`tag_id`),
  CONSTRAINT `posts_tags_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`),
  CONSTRAINT `posts_tags_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts_tags`
--

LOCK TABLES `posts_tags` WRITE;
/*!40000 ALTER TABLE `posts_tags` DISABLE KEYS */;
INSERT INTO `posts_tags` VALUES ('6091ec1d517db00001e537e1','6091ec1c517db00001e536e1','6091ec1b517db00001e53682',0),('6091ec1d517db00001e537e2','6091ec1c517db00001e536e3','6091ec1b517db00001e53682',0),('6091ec1d517db00001e537e3','6091ec1c517db00001e536eb','6091ec1b517db00001e53682',0),('6091ec1d517db00001e537e4','6091ec1c517db00001e536e9','6091ec1b517db00001e53682',0),('6091ec1d517db00001e537e5','6091ec1c517db00001e536ed','6091ec1b517db00001e53682',0),('6091ec1d517db00001e537e6','6091ec1c517db00001e536e7','6091ec1b517db00001e53682',0),('6091ec1d517db00001e537e7','6091ec1c517db00001e536e5','6091ec1b517db00001e53682',0);
/*!40000 ALTER TABLE `posts_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` varchar(24) NOT NULL,
  `name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `products_name_unique` (`name`),
  UNIQUE KEY `products_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES ('6091ec1b517db00001e53681','Default Product','default-product','2021-05-05 00:51:39','2021-05-05 00:51:39');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` varchar(24) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `created_by` varchar(24) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` varchar(24) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES ('6091ec1b517db00001e53683','Administrator','Administrators','2021-05-05 00:51:39','1','2021-05-05 00:51:39','1'),('6091ec1b517db00001e53684','Editor','Editors','2021-05-05 00:51:39','1','2021-05-05 00:51:39','1'),('6091ec1b517db00001e53685','Author','Authors','2021-05-05 00:51:39','1','2021-05-05 00:51:39','1'),('6091ec1b517db00001e53686','Contributor','Contributors','2021-05-05 00:51:39','1','2021-05-05 00:51:39','1'),('6091ec1b517db00001e53687','Owner','Blog Owner','2021-05-05 00:51:39','1','2021-05-05 00:51:39','1'),('6091ec1b517db00001e53688','Admin Integration','External Apps','2021-05-05 00:51:39','1','2021-05-05 00:51:39','1'),('6091ec1b517db00001e53689','DB Backup Integration','Internal DB Backup Client','2021-05-05 00:51:39','1','2021-05-05 00:51:39','1'),('6091ec1c517db00001e5368a','Scheduler Integration','Internal Scheduler Client','2021-05-05 00:51:40','1','2021-05-05 00:51:40','1');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles_users`
--

DROP TABLE IF EXISTS `roles_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles_users` (
  `id` varchar(24) NOT NULL,
  `role_id` varchar(24) NOT NULL,
  `user_id` varchar(24) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles_users`
--

LOCK TABLES `roles_users` WRITE;
/*!40000 ALTER TABLE `roles_users` DISABLE KEYS */;
INSERT INTO `roles_users` VALUES ('6091ec1c517db00001e536e0','6091ec1b517db00001e53686','5951f5fca366002ebd5dbef7'),('6091ec1d517db00001e537e8','6091ec1b517db00001e53687','1');
/*!40000 ALTER TABLE `roles_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(24) NOT NULL,
  `session_id` varchar(32) NOT NULL,
  `user_id` varchar(24) NOT NULL,
  `session_data` varchar(2000) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sessions_session_id_unique` (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('6091eef9517db00001e53838','0JNgO582c_u3in1XeJaIwikwbvgjBr4b','1','{\"cookie\":{\"originalMaxAge\":15768000000,\"expires\":\"2021-11-03T13:03:53.045Z\",\"secure\":false,\"httpOnly\":true,\"path\":\"/ghost\",\"sameSite\":\"lax\"},\"user_id\":\"1\",\"origin\":\"http://localhost:8080\",\"user_agent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36\",\"ip\":\"172.20.0.1\"}','2021-05-05 01:03:53','2021-05-05 01:03:53');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` varchar(24) NOT NULL,
  `group` varchar(50) NOT NULL DEFAULT 'core',
  `key` varchar(50) NOT NULL,
  `value` text DEFAULT NULL,
  `type` varchar(50) NOT NULL,
  `flags` varchar(50) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `created_by` varchar(24) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` varchar(24) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `settings_key_unique` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES ('6091ec1d517db00001e537e9','core','db_hash','f91b45b5-43d6-4038-91ed-755031260f8c','string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1d517db00001e537ea','core','routes_hash','3d180d52c663d173a6be791ef411ed01','string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:43','1'),('6091ec1d517db00001e537eb','core','next_update_check','1620262811','number',NULL,'2021-05-05 00:51:42','1','2021-05-05 01:00:11','1'),('6091ec1d517db00001e537ec','core','notifications','[]','array',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1d517db00001e537ed','core','session_secret','ead0cd33cbbf7f8d0631243dd97205b0633ae8d39c4e61a23c368f3efb6529fc','string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1d517db00001e537ee','core','theme_session_secret','073c9842a3c10bc6edc1eaec1ab2f0dd7da335a795e7d78824a6313f4e1187e1','string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1d517db00001e537ef','core','ghost_public_key','-----BEGIN RSA PUBLIC KEY-----\nMIGJAoGBAJ9F+fr/f1CJwf9NJK25cvki7xdkngPvndsOUK1UYvxtAf5ZECGo+HIDAIA9VS6G\nkhP0NRaeSA3tNvUdxbUc3/pcTbxK9yhqoV2O6YjwqckJvyg0BejB76h2mxa1eN4CqDSJ5Cyg\nt4Ya7/GBV1tvq98QKdOWkKJhmbXIC1y6g8TlAgMBAAE=\n-----END RSA PUBLIC KEY-----\n','string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1d517db00001e537f0','core','ghost_private_key','-----BEGIN RSA PRIVATE KEY-----\nMIICXgIBAAKBgQCfRfn6/39QicH/TSStuXL5Iu8XZJ4D753bDlCtVGL8bQH+WRAhqPhyAwCA\nPVUuhpIT9DUWnkgN7Tb1HcW1HN/6XE28SvcoaqFdjumI8KnJCb8oNAXowe+odpsWtXjeAqg0\nieQsoLeGGu/xgVdbb6vfECnTlpCiYZm1yAtcuoPE5QIDAQABAoGAOxodZA1xMfKcgV8f8DMz\nvc0/yX91v2IoQoQyXc9FmAPfTIHCIatw3eXNRsj7lfMru6nQFV+Qv1I6JYTxu35GgitVVqVU\nRNxdnlyoMzWzD8khO6wYYvp2GxVIrSx0yiSMGGUOHI6jaxspDb4T3u79tkNrT0VxAvBonCVO\nhA/KZJUCQQDcXzltIFOhDazNsvHGxk4v3wAB9q/J8WjTZJ+VNq0fLdWBPx8Yxywiry25WhpL\nAJRPw/1UNEiBJ55Ei8dvQ3TXAkEAuQX/ILdti37hxmA/COUYjN9LwF61kJ6eLJbgAKsNWMO4\n43V8jyvHEsoLjRtRmRaRQiJKQY7H3cbQ2TXx14agowJBALUeEk2NHw6j9Z1N8AZln4caqZ/z\nhoDbx0LOVZZGTLzuZ6aFIWK096I+Bb9rvWZdQIfaVc+p9NkpnZtKoovgjhsCQQC1v587CxQP\neEbd8ENbQHgaQWqPADnIYxerY1WNMnm83R3sScdeeDloSpKIPPKtt85esYJR3aiVQSx8ghIb\njcKTAkEAw/Er9/Tkzs6FlVC3YRvAjxzr+PwaCbtdDcVh2Rbx9tyROu0FBpEK2mCJc6aFPJqQ\ngy7VO9PiYZ2vfuIeyKnggQ==\n-----END RSA PRIVATE KEY-----\n','string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e537f1','core','members_public_key','-----BEGIN RSA PUBLIC KEY-----\nMIGJAoGBALr1NM6ZNwI6skipvTnftcznrupRmBgFe0KZB7PT0BglvCNkakQiBH3fMtH07RoK\nuGZb3sgDK27IRN2ebvMVcHWUdgIW3yb8cIc6/hAfVdav9R2qlBdjHV+cKiQ/CnTjdL0RBECL\nAN3zccSYjr/Nkdkbvkh7hjSd/ifizUEl3qCTAgMBAAE=\n-----END RSA PUBLIC KEY-----\n','string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e537f2','core','members_private_key','-----BEGIN RSA PRIVATE KEY-----\nMIICWwIBAAKBgQC69TTOmTcCOrJIqb0537XM567qUZgYBXtCmQez09AYJbwjZGpEIgR93zLR\n9O0aCrhmW97IAytuyETdnm7zFXB1lHYCFt8m/HCHOv4QH1XWr/UdqpQXYx1fnCokPwp043S9\nEQRAiwDd83HEmI6/zZHZG75Ie4Y0nf4n4s1BJd6gkwIDAQABAoGAUTPJoOZZRyWZZAgdgTKS\ncxI6HdoctmpDFDUFbGzWWHajVbf6k+c2jjlQiHLaPNJlL0g95h/CUJa5moyC4h/wvNMYnZUu\nxBYcTtVAUCE+rzn9HtoA96epwstZCdSNSdHmBg2xrrtAsr4S+jUhuoP7QT4cK5Go9I/G7Kjb\nEGZFnFECQQDa1Rn6z1OF0qc0p4Jp6rQyGy1hK8sAAi9kmcdxED9L1Zdb5w+uPHmz5gDi37hX\nKMtyDglTjUAJF7bfJwiSVpt7AkEA2rYwLSV2Q8p3IzS3cUbCwjwap21Wey2VvmMR1Ff9f4U/\nFvTqBWn2RMz5TQ3L/bqIUBwHF5l/EzEHld49PauXyQJAIRY5cF+qnEBGgcKWCFexWSYczWVm\nsyChc8+AhUrUly27Tez4xPpl2Fp9ZdA3ug3z/NG8fUKNHRLV1pW7SQ0JQwJALO3WUb/rXpu+\nA651rMCDi9E7DH/qjx1bMKQ7amq0+bhOsJGZbYlJ/PI6mHioGjRygjpvvopaz3939nKUFBIm\n+QJAM1zTY7RseeXJE+IHLgGDCF6N84eVPkxAE23SdcrM+qi10J3B0C39VxXuE26OI/Co4/Gf\neRN4cuesSlFtOqqXQg==\n-----END RSA PRIVATE KEY-----\n','string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e537f3','core','members_email_auth_secret','b3829ce5276167c6e5258f001ac89f38b3efffee351dab8636efd2ac1cce714110c9bab063944266a894c00fd230415040bf7ad320628b3056c2905b16e89a01','string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e537f4','core','members_stripe_webhook_id',NULL,'string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e537f5','core','members_stripe_webhook_secret',NULL,'string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e537f6','site','title','The My Awesome','string','PUBLIC','2021-05-05 00:51:42','1','2021-05-05 01:03:52','1'),('6091ec1e517db00001e537f7','site','description','Thoughts, stories and ideas.','string','PUBLIC','2021-05-05 00:51:42','1','2021-05-05 01:03:52','1'),('6091ec1e517db00001e537f8','site','logo','','string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e537f9','site','cover_image','https://static.ghost.org/v4.0.0/images/publication-cover.jpg','string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e537fa','site','icon','','string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e537fb','site','accent_color','#a20294','string','PUBLIC','2021-05-05 00:51:42','1','2021-05-05 01:13:29','1'),('6091ec1e517db00001e537fc','site','lang','en','string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e537fd','site','timezone','Etc/UTC','string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e537fe','site','codeinjection_head','','string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e537ff','site','codeinjection_foot','','string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e53800','site','facebook','ghost','string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e53801','site','twitter','@ghost','string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e53802','site','navigation','[{\"label\":\"Home\",\"url\":\"/\"},{\"label\":\"About\",\"url\":\"/about/\"},{\"label\":\"Collection\",\"url\":\"/tag/getting-started/\"},{\"label\":\"Author\",\"url\":\"/author/ghost/\"},{\"label\":\"Portal\",\"url\":\"/portal/\"}]','array',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e53803','site','secondary_navigation','[{\"label\":\"Data & privacy\",\"url\":\"/privacy/\"},{\"label\":\"Contact\",\"url\":\"/contact/\"},{\"label\":\"Contribute →\",\"url\":\"/contribute/\"}]','array',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e53804','site','meta_title',NULL,'string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e53805','site','meta_description',NULL,'string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e53806','site','og_image',NULL,'string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e53807','site','og_title',NULL,'string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e53808','site','og_description',NULL,'string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e53809','site','twitter_image',NULL,'string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e5380a','site','twitter_title',NULL,'string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e5380b','site','twitter_description',NULL,'string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e5380c','theme','active_theme','casper','string','RO','2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e5380d','private','is_private','false','boolean',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e5380e','private','password','','string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e5380f','private','public_hash','a10440a32936e89707b8b14eb0a583','string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e53810','members','default_content_visibility','public','string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e53811','members','members_signup_access','all','string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e53812','members','members_from_address','noreply','string','RO','2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e53813','members','members_support_address','noreply','string','PUBLIC,RO','2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e53814','members','members_reply_address','newsletter','string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e53815','members','members_free_signup_redirect','/','string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e53816','members','members_paid_signup_redirect','/','string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e53817','members','stripe_product_name','Ghost Subscription','string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e53818','members','stripe_secret_key',NULL,'string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e53819','members','stripe_publishable_key',NULL,'string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e5381a','members','stripe_plans','[{\"name\":\"Monthly\",\"currency\":\"usd\",\"interval\":\"month\",\"amount\":500},{\"name\":\"Yearly\",\"currency\":\"usd\",\"interval\":\"year\",\"amount\":5000}]','array',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e5381b','members','stripe_connect_publishable_key',NULL,'string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e5381c','members','stripe_connect_secret_key',NULL,'string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e5381d','members','stripe_connect_livemode',NULL,'boolean',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e5381e','members','stripe_connect_display_name',NULL,'string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e5381f','members','stripe_connect_account_id',NULL,'string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e53820','portal','portal_name','true','boolean',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e53821','portal','portal_button','true','boolean',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e53822','portal','portal_plans','[\"free\",\"monthly\",\"yearly\"]','array',NULL,'2021-05-05 00:51:42','1','2021-05-05 01:04:31','1'),('6091ec1e517db00001e53823','portal','portal_button_style','icon-and-text','string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e53824','portal','portal_button_icon',NULL,'string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e53825','portal','portal_button_signup_text','Subscribe','string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e53826','email','mailgun_domain',NULL,'string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e53827','email','mailgun_api_key',NULL,'string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e53828','email','mailgun_base_url',NULL,'string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e53829','email','email_track_opens','true','boolean',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e5382a','amp','amp','true','boolean',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e5382b','amp','amp_gtag_id',NULL,'string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e5382c','firstpromoter','firstpromoter','false','boolean',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e5382d','firstpromoter','firstpromoter_id',NULL,'string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e5382e','slack','slack_url','','string',NULL,'2021-05-05 00:51:42','1','2021-05-05 01:13:29','1'),('6091ec1e517db00001e5382f','slack','slack_username','Ghost','string',NULL,'2021-05-05 00:51:42','1','2021-05-05 01:13:29','1'),('6091ec1e517db00001e53830','unsplash','unsplash','true','boolean',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e53831','views','shared_views','[]','array',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e53832','newsletter','newsletter_show_badge','true','boolean',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e53833','newsletter','newsletter_show_header','true','boolean',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e53834','newsletter','newsletter_body_font_category','sans_serif','string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e53835','newsletter','newsletter_footer_content','','string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e53836','oauth','oauth_client_id',NULL,'string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1'),('6091ec1e517db00001e53837','oauth','oauth_client_secret',NULL,'string',NULL,'2021-05-05 00:51:42','1','2021-05-05 00:51:42','1');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `snippets`
--

DROP TABLE IF EXISTS `snippets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `snippets` (
  `id` varchar(24) NOT NULL,
  `name` varchar(191) NOT NULL,
  `mobiledoc` longtext NOT NULL,
  `created_at` datetime NOT NULL,
  `created_by` varchar(24) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` varchar(24) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `snippets_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `snippets`
--

LOCK TABLES `snippets` WRITE;
/*!40000 ALTER TABLE `snippets` DISABLE KEYS */;
/*!40000 ALTER TABLE `snippets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stripe_prices`
--

DROP TABLE IF EXISTS `stripe_prices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stripe_prices` (
  `id` varchar(24) NOT NULL,
  `stripe_price_id` varchar(255) NOT NULL,
  `stripe_product_id` varchar(255) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `nickname` varchar(50) DEFAULT NULL,
  `currency` varchar(191) NOT NULL,
  `amount` int(11) NOT NULL,
  `type` varchar(50) NOT NULL DEFAULT 'recurring',
  `interval` varchar(50) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `stripe_prices_stripe_price_id_unique` (`stripe_price_id`),
  KEY `stripe_prices_stripe_product_id_foreign` (`stripe_product_id`),
  CONSTRAINT `stripe_prices_stripe_product_id_foreign` FOREIGN KEY (`stripe_product_id`) REFERENCES `stripe_products` (`stripe_product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stripe_prices`
--

LOCK TABLES `stripe_prices` WRITE;
/*!40000 ALTER TABLE `stripe_prices` DISABLE KEYS */;
/*!40000 ALTER TABLE `stripe_prices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stripe_products`
--

DROP TABLE IF EXISTS `stripe_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stripe_products` (
  `id` varchar(24) NOT NULL,
  `product_id` varchar(24) NOT NULL,
  `stripe_product_id` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `stripe_products_stripe_product_id_unique` (`stripe_product_id`),
  KEY `stripe_products_product_id_foreign` (`product_id`),
  CONSTRAINT `stripe_products_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stripe_products`
--

LOCK TABLES `stripe_products` WRITE;
/*!40000 ALTER TABLE `stripe_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `stripe_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
  `id` varchar(24) NOT NULL,
  `name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `feature_image` varchar(2000) DEFAULT NULL,
  `parent_id` varchar(191) DEFAULT NULL,
  `visibility` varchar(50) NOT NULL DEFAULT 'public',
  `og_image` varchar(2000) DEFAULT NULL,
  `og_title` varchar(300) DEFAULT NULL,
  `og_description` varchar(500) DEFAULT NULL,
  `twitter_image` varchar(2000) DEFAULT NULL,
  `twitter_title` varchar(300) DEFAULT NULL,
  `twitter_description` varchar(500) DEFAULT NULL,
  `meta_title` varchar(2000) DEFAULT NULL,
  `meta_description` varchar(2000) DEFAULT NULL,
  `codeinjection_head` text DEFAULT NULL,
  `codeinjection_foot` text DEFAULT NULL,
  `canonical_url` varchar(2000) DEFAULT NULL,
  `accent_color` varchar(50) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `created_by` varchar(24) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` varchar(24) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tags_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
INSERT INTO `tags` VALUES ('6091ec1b517db00001e53682','Getting Started','getting-started',NULL,NULL,NULL,'public',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-05-05 00:51:39','1','2021-05-05 00:51:39','1');
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tokens` (
  `id` varchar(24) NOT NULL,
  `token` varchar(32) NOT NULL,
  `data` varchar(2000) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `created_by` varchar(24) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tokens_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` varchar(24) NOT NULL,
  `name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `password` varchar(60) NOT NULL,
  `email` varchar(191) NOT NULL,
  `profile_image` varchar(2000) DEFAULT NULL,
  `cover_image` varchar(2000) DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `website` varchar(2000) DEFAULT NULL,
  `location` text DEFAULT NULL,
  `facebook` varchar(2000) DEFAULT NULL,
  `twitter` varchar(2000) DEFAULT NULL,
  `accessibility` text DEFAULT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'active',
  `locale` varchar(6) DEFAULT NULL,
  `visibility` varchar(50) NOT NULL DEFAULT 'public',
  `meta_title` varchar(2000) DEFAULT NULL,
  `meta_description` varchar(2000) DEFAULT NULL,
  `tour` text DEFAULT NULL,
  `last_seen` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `created_by` varchar(24) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` varchar(24) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_slug_unique` (`slug`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('1','My Full Name','my','$2a$10$zVdJbNNkBmJbP1cyOQVx1eV9McREOaTTsWV1GuT0sKwCz88DNa2b6','lucasbasquerotto@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"launchComplete\":true,\"nightShift\":true}','active',NULL,'public',NULL,NULL,NULL,'2021-05-05 01:03:53','2021-05-05 00:51:40','1','2021-05-05 01:07:51','1'),('5951f5fca366002ebd5dbef7','Ghost','ghost','$2a$10$bhcYn8QuwXpVfhAR.5VtXe9EDlTfSVm9v5uOCVITrmeZMRba.E1xW','ghost-author@example.com','https://static.ghost.org/v4.0.0/images/ghost-user.png',NULL,'You can delete this user to remove all the welcome posts','https://ghost.org','The Internet','ghost','ghost',NULL,'active',NULL,'public',NULL,NULL,NULL,NULL,'2021-05-05 00:51:40','1','2021-05-05 00:51:40','1');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webhooks`
--

DROP TABLE IF EXISTS `webhooks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `webhooks` (
  `id` varchar(24) NOT NULL,
  `event` varchar(50) NOT NULL,
  `target_url` varchar(2000) NOT NULL,
  `name` varchar(191) DEFAULT NULL,
  `secret` varchar(191) DEFAULT NULL,
  `api_version` varchar(50) NOT NULL DEFAULT 'v2',
  `integration_id` varchar(24) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'available',
  `last_triggered_at` datetime DEFAULT NULL,
  `last_triggered_status` varchar(50) DEFAULT NULL,
  `last_triggered_error` varchar(50) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `created_by` varchar(24) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` varchar(24) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `webhooks_integration_id_foreign` (`integration_id`),
  CONSTRAINT `webhooks_integration_id_foreign` FOREIGN KEY (`integration_id`) REFERENCES `integrations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webhooks`
--

LOCK TABLES `webhooks` WRITE;
/*!40000 ALTER TABLE `webhooks` DISABLE KEYS */;
/*!40000 ALTER TABLE `webhooks` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-05-05  1:31:01
